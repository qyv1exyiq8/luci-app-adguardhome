#!/bin/bash /etc/ikcommon

Include iptables.sh errcode.sh

register_module_urls()
{
	echo "url=system/remote-access  name=remote_control get=data post= put=save delete= post_require_body=1"
}

boot()
{
	ipset -N Linux_webport_default bitmap:port range 0-65535
	if [ "$DEVELOPER" ];then
		vsftpd
	fi
	sqlite3 $IK_DB_CONFIG "update remote_control set force_https=1"

	init boot
}

init()
{
	local is_boot="$1"
	if [ "$is_boot" ];then
		local $(sql_config_get_list $IK_DB_CONFIG "select * from remote_control")
		local sshd_passwd=$(__sql_passwd_dec $sshd_passwd)
	fi

	__set_wanweb
	__set_http_server
	__set_telnetd $is_boot
	__set_sshd
	__create_config_cache
}

__console_set_sshd() {
	local $(sql_config_get_list $IK_DB_CONFIG "update remote_control set open_sshd=$open_sshd; select open_sshd,sshd_port from remote_control")
#	local sshd_passwd=$(__sql_passwd_dec $sshd_passwd)
	__set_sshd	
	__create_config_cache
}

__console_set_wanweb() {
	sqlite3 $IK_DB_CONFIG "update remote_control set open_wanweb=$open_wanweb"
	__set_wanweb
	__create_config_cache
}

__console_set_http_server() {
	local $(sql_config_get_list $IK_DB_CONFIG "update remote_control set http_port=$http_port; select http_port,https_port,force_https from remote_control")
	__set_http_server	
	__create_config_cache
}

__create_config_cache()
{
	sql_config_get_list $IK_DB_CONFIG "select * from remote_control" >$IK_DIR_CACHE/remote_control
}

save()
{
	if ! errmsg=$(__check_param); then
		outputErrorLog "errcode_param_error" "$errmsg"
		return 1
	fi
	local $(sql_config_get_list $IK_DB_CONFIG "select * from remote_control" prefix=old_)

	local orign_sshd_passwd="$sshd_passwd"
	local sshd_passwd=$(__sql_passwd_enc "$sshd_passwd")
	local force_https=1
	local sql_param="force_https:int http_port:int https_port:int open_telnetd:int open_wanweb:int open_sshd:int sshd_port:int sshd_passwd:str"
	if SqlMsg=$(sql_config_update $IK_DB_CONFIG remote_control "id=1" $sql_param) ;then
		local sshd_passwd="$orign_sshd_passwd"
		init >/dev/null 2>&1 &
		return 0
	else
		outputErrorLog "errcode_db_error" "$SqlMsg"
		return 1
	fi
}

dump_info()
{
	$IK_DIR_SCRIPT/utils/export_sysinfo.sh >/dev/null 2>&1
	echo debug_syslog.gz
	return 0
}

show()
{
	Show __json_result__
}

__implant_code()
{
cat -<<EOF
        ikdb:create_function('passwd_dec',1,
                function (ctx, sshd_passwd)
                        local res = ""
                        if not sshd_passwd:match("^[0-9A-F]+$") then
                                ctx:result_text("")
                                return
                        end
                        local cmd = string.format("ikluajit /usr/ikuai/script/sec/comm_enc.lua decrypt input=%s", sshd_passwd)
                        local f = io.popen(cmd)
                        if f then
                                res = f:read("*l")
                                f:close()
                        end

                        ctx:result_text(res or "")
                end
        )
EOF
}

__show_data()
{
	local __sql_implant_code__=$(__implant_code)
	local sql_show="select *,passwd_dec(sshd_passwd)  sshd_passwd from remote_control"
#	local sql_show="select * from remote_control"
	local data=$(sql_config_get_json $IK_DB_CONFIG "$sql_show")

	json_append __json_result__ data:json
}

__set_wanweb()
{
	if [ "$old_open_wanweb" = "$open_wanweb" ];then
		return
	fi

	iptables -w -F WEBACL
	ip6tables -w -F WEBACL
	#如果是关闭状态,那么我们加一条阻止外网访问web管理端口的规则
	if [ "$open_wanweb" = "0" ];then
		iptables -w -A WEBACL -p tcp $IPT_WAN_NO_VPN_IFACE_IN -m set --match-set Linux_webport_default dst -j DROP
		ip6tables -w -A WEBACL -p tcp $IPT_WAN_NO_VPN_IFACE_IN -m set --match-set Linux_webport_default dst -j DROP
	elif [ "$open_wanweb" = "2" ];then
		ip6tables -w -A WEBACL -p tcp $IPT_WAN_NO_VPN_IFACE_IN -m set --match-set Linux_webport_default dst -j DROP
	elif [ "$open_wanweb" = "3" ];then
		iptables -w -A WEBACL -p tcp $IPT_WAN_NO_VPN_IFACE_IN -m set --match-set Linux_webport_default dst -j DROP
	fi
}

__set_telnetd()
{
	if [ "$old_open_telnetd" = "$open_telnetd" ];then
		return
	fi

	#开机启动时 不kill telnetd, 可能需要产测的telnetd启动
	if [ ! "$is_boot" ];then
		killall -q telnetd
	fi

	if [ "$open_telnetd" = "1" ];then
		env - PATH=$PATH TELNETD=1 telnetd -l /etc/setup/rc.console
	fi
}

__set_sshd()
{
	if ! NewOldVarl open_sshd sshd_port sshd_passwd ;then
		if [ "$sshd_passwd" != "$old_sshd_passwd" ];then
			echo -e "$sshd_passwd\n$sshd_passwd\n"|passwd sshd >/dev/null 2>/dev/null
		fi
		killall -q dropbear
		if [ "$open_sshd" = "1" -o "$DEVELOPER" ];then
			env - PATH=$PATH dropbear -p $sshd_port
			# === iKuai 加固：SSH 仅 LAN 放行，WAN 拒掉（拦截远控 SSH 通道，仅本地 WinSCP/SCP 可用） ===
			# ik_wan_input 链 iKuai 用于过滤来自 WAN 的入站，默认会放通 SSH；
			# 这里加一条 DROP 优先级最高的规则，禁止公网 22/tcp
			iptables -I ik_wan_input 1 -p tcp --dport $sshd_port -j DROP 2>/dev/null
		fi
		if [ "$sshd_port" != "$old_sshd_port" ]; then
			$IK_DIR_SCRIPT/upnpd.sh start >/dev/null 2>&1 &
		fi
	fi
}

__set_http_server()
{
	local webserver_dir="/usr/openresty"

	if NewOldVarl http_port https_port force_https ;then
		return
	fi

	if ! NewOldVarl http_port https_port; then
		$IK_DIR_SCRIPT/upnpd.sh start >/dev/null 2>&1 &
	fi

	if ! NewOldVarl http_port https_port ;then
		ipset -F Linux_webport_default
		ipset -! -A Linux_webport_default $http_port
		ipset -! -A Linux_webport_default $https_port
	fi

	#设置web管理端口
	echo "listen $http_port;"  >$webserver_dir/conf/http_port.conf
	echo "listen [::]:$http_port;"  >>$webserver_dir/conf/http_port.conf
	echo "listen $https_port ssl;" >$webserver_dir/conf/https_port.conf
	echo "listen [::]:$https_port ssl;" >>$webserver_dir/conf/https_port.conf

	#强制使用HTTPS
	if [ "$force_https" = 1 -a "$https_port" -gt 0 ];then
		echo "set \$force_https 1;" >> $webserver_dir/conf/http_port.conf
		echo "set \$https_port $https_port;" >> $webserver_dir/conf/http_port.conf
	fi

	local server_conf

	#这个是临时起的http端口,用于远控
	Append server_conf "$LINE_N" "include conf/webman_temp.conf;"
	Append server_conf "$LINE_N" "include conf/webman_local.conf;"

	#启用HTTP服务
	if [ "$http_port" -gt 0 ];then
		Append server_conf "$LINE_N" "include conf/webman_http.conf;"
	fi

	#启用HTTPS服务
	if [ "$https_port" -gt 0 ];then
		Append server_conf "$LINE_N" "include conf/webman_https.conf;"
	fi

	#重载NGINX配置
	echo "$server_conf" >$webserver_dir/conf/server.conf
	openresty -s reload
}

__check_param()
{
	check_varl \
		'open_telnetd  == "0" or == "1"'\
		'open_wanweb   == "0" or == "1" or == "2" or == "3"'\
		'open_sshd     == "0" or == "1"'\
		'force_https   == "0" or == "1"'\
		'sshd_passwd   length >= 6 and length <= 64'\
		'sshd_passwd   != ""'\
		'sshd_port     == "0" or ikports'\
		'http_port     == "0" or ikports'\
		'https_port    == "0" or ikports' \
		'[ http_port   == %http_ports% ] && {
			http_port > 0 ;
		}'
}

