
local ResCallBodyErr  = 10006  --Body内容太大
local ResCallJsonErr  = 10007  --Json格式错误
local ResCallParamErr = 10008  --参数内容错误
local ResIkrestErr    = 10013  --ik_rest HTTP 状态错误 
local ResCmdFileErr   = 10014  --CommandFile HTTP 状态错误 

if ngx.var.request_method ~= "POST" and ngx.var.request_method ~= "PUT" then
	ngx.exit(401)
end

if ngx.var.http_x_actionproxy then
	ngx.exit(403)
end

ngx.req.read_body()
if not ngx.var.request_body then
	ikngx.senderror(ResCallBodyErr, "Post body too large")
end

local ngx_var_uri = ngx.var.uri

if ngx_var_uri == "/command/file" then
	ikngx.senderror2(ResCmdFileErr, "not support")
	local shell = require "resty.shell"
	local ngx_pipe = require "ngx.pipe"
	local timeout = 60000     --60s
	local max_size = 10485760 --10Mbyte

	local stdin = ngx.var.request_body
	
	local cmd = stdin:match("^#!([^\n]+)")
	local cmd_tab
	if cmd then
		cmd_tab = ikngx.split(cmd, " +")
	else
		cmd_tab = {"bash"}
	end

	local ok, stdout, stderr, reason, status = shell.run(cmd_tab, stdin, timeout, max_size)
	cmd = nil
	collectgarbage("collect")
	if reason == "exit" then
		ngx.header["Content-Length"] = #stdout
		ngx.print(stdout)
	else
		ikngx.senderror2(ResCmdFileErr, stdout)
	end

else
	local res, call_json_tab = pcall(cjson.decode, ngx.var.request_body)
	if not res then
		ikngx.senderror(ResCallJsonErr, "decode json fail")
	end

	local func_name = call_json_tab["func_name"]
	if not func_name or func_name == "" then
		ikngx.senderror(ResCallParamErr, 'func_name is null')
	end

	local action = call_json_tab["action"]
	if not action or action == "" then
		ikngx.senderror(ResCallParamErr, 'action is null')
	end

	local env = {
		IKREST_REFERER = "ik-http-server",
	}

	local ok, buf = ikngx.rest(call_json_tab, env)
	ngx.header["Content-Type"]  = "application/json;charset=UTF-8"

	if ok then	
		ngx.header["Content-Length"] = #buf
		ngx.print(buf)
	else
		ikngx.senderror2(ResIkrestErr, buf)
	end


end

ngx.exit(0)
