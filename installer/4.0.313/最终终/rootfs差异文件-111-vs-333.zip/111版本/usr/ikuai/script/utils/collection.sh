#!/bin/bash /etc/ikcommon
Include sys/sysstat.sh,interface.sh

BANDWIDTH_STAT_CACHE="/tmp/iktmp/bandwidth_stat"
EXTEND_WORK_DIR="/etc/disk_sys/audit"
today_total_file_tmp="/tmp/iktmp/cache/term_today_total.tmp"
today_total_file="/tmp/iktmp/cache/term_today_total"
flow_control_cache="$IK_DIR_CACHE/flow_control"

__ensure_offline_wireless_columns()
{
	local __db="$1"
	local __table

	[ -f "$__db" ] || return 0
	for __table in offline_record offline_record6; do
		sqlite3 "$__db" "alter table $__table add column frequencies text default ''" >/dev/null 2>&1 || true
		sqlite3 "$__db" "alter table $__table add column apmac text default ''" >/dev/null 2>&1 || true
		sqlite3 "$__db" "alter table $__table add column bssid text default ''" >/dev/null 2>&1 || true
		sqlite3 "$__db" "alter table $__table add column ssid text default ''" >/dev/null 2>&1 || true
	done
}

__ensure_collection_wireless_columns()
{
	__ensure_offline_wireless_columns "$IK_DIR_LOG/collection.db"
	[ -f "$EXTEND_WORK_DIR/collection.db" ] && __ensure_offline_wireless_columns "$EXTEND_WORK_DIR/collection.db"
}

boot()
{
	[ "$SUPPORT_MINI_FUNC" ] && return

	Include crond.sh

	mkdir -p /etc/log/client_type
	crond_clean collection
	crond_insert collection "* * * * * nice $IK_DIR_SCRIPT/utils/collection.sh start"
	crond_commit
}

ik_dns_cache_stat() {
	#ikuai dns cache statistics

	if [ ! -e "/tmp/iktmp/ikdnsd.status" ]; then
		return 0
	fi
	if [ ! -e "/tmp/iktmp/ikdnsd.report.txt" ] ; then
		return 0
	fi

	cp /tmp/iktmp/ikdnsd.report.txt  $TMP_DIR/new/dns-accum
	
	local $(cat $TMP_DIR/new/dns-accum)
	#获取当前统计
	local hit=$((count_query-count_miss))
	local miss=$count_miss
	local request=$count_query
	
	#获取当前日期
	local now_timestamp=$(date +%s)
	local yest_timestamp=$((now_timestamp-24*60*60))
	local date_now=$(date +%F)
	local date_yest=$(date +%F -d @$yest_timestamp)

	#获取上一次统计
	local old_hit old_miss old_request
	if [ -e "$TMP_DIR/old/dns-accum" ];then
		local $(cat $TMP_DIR/old/dns-accum)
		old_hit=$((count_query-count_miss))
		old_miss=$count_miss
		old_request=$count_query
	else
		old_request=0
		old_hit=0
		old_miss=0
	fi

	local diff_request diff_hit diff_miss
	#老数据大于新数据，则直接使用新数据值，因为再重新加载dnscache 服务的时候，数据会清零，所以新数据会小于老数据。
	if [ "$old_request" -le "$request" -a "$old_hit" -le "$hit" -a "$old_miss" -le "$miss"  ];then 
		diff_request=$((request-old_request))
		diff_hit=$((hit-old_hit))
		diff_miss=$((miss-old_miss))
	else
		diff_request=$request
		diff_hit=$hit
		diff_miss=$miss
	fi

	#如果id 2 的date 不等于 date_now, 则删除 id 1（即前天）
	#然后把 id 2 改成 id 1
	#最后重新建立一条全新的 id 2
	echo "update dns_cache_stat set id=0,date='$date_now',request=0,hit=0,miss=0,save_time=0 where id=1 and '$date_now'!=(select date from dns_cache_stat where id=2);"  >>/tmp/collection.temp.conf
	echo "update dns_cache_stat set id=1 where id=2 and '$date_now'!=(select date from dns_cache_stat where id=2);"  >>/tmp/collection.temp.conf
	echo "update dns_cache_stat set date='$date_yest',request=0,hit=0,miss=0,save_time=0 where id=1 and date != '$date_yest';"  >>/tmp/collection.temp.conf
	echo "update dns_cache_stat set id=2 where id=0 ;"  >>/tmp/collection.temp.conf
	#追加当天统计
	echo "update dns_cache_stat set request=request+$diff_request,hit=hit+$diff_hit,miss=miss+$diff_miss where id = 2 ;"  >>/tmp/collection.temp.conf
	#追加累积统计
	echo "update dns_cache_stat set request=request+$diff_request,hit=hit+$diff_hit,miss=miss+$diff_miss where id = 3 ;"  >>/tmp/collection.temp.conf
		
}


ik_cache_lan_prefix_addr()
{
	echo "delete from prefix_stat;" >> /tmp/collection.temp.conf	

	for conf_file in $(ls $IK_DIR_CACHE/config/ipv6_lan_config.*); do
		local $(cat $conf_file)
		[ "$enabled" = "yes" ] || continue

		if [ "$internet" = "relay" ]; then
			if [ -e "/tmp/iktmp/dhcp6c/$parent" ]; then
				local $(cat /tmp/iktmp/dhcp6c/$parent)
				if [ "$dhcp6_prefix1" ]; then
					local addr6="$dhcp6_prefix1"
					echo "insert into prefix_stat(interface, new_ipv6_addr, old_ipv6_addr) values('$interface','${addr6//\/*/}','${addr6//\/*/}');" >> /tmp/collection.temp.conf
				fi
			fi
		else
			for addr6 in $(interface_get_ipv6addr_mask $interface); do
				echo "insert into prefix_stat(interface, new_ipv6_addr, old_ipv6_addr) values('$interface','${addr6//\/*/}','${addr6//\/*/}');" >> /tmp/collection.temp.conf
			done
		fi
	done
}

__cache_bandwidth_stat() {
	local dtype="$1"
        local ifname sql_filter_name
        local ifnames=$(interface_get_ifname wan)
        for ifname in $ifnames; do
                local sql_filter_name+=${sql_filter_name:+or }"name='$ifname' "
        done
        sql_filter_name="($sql_filter_name)"
	
	if [ "$dtype" = "day" ];then
		local recent_days=1
	elif [ "$dtype" = "week" ];then
		local recent_days=7
	else
		local recent_days=31
	fi

        local sql_rdays_param="where timestamp > strftime('%s', 'now', '-${recent_days:-1} day') and timestamp < strftime('%s', 'now') and $sql_filter_name"

	#每个wan口的带宽使用率
	local sql_show="select name,round(avg(cast(upload_use as float)),2) as upload,round(avg(cast(download_use as float)),2) as download from bandwidth_stat $sql_rdays_param group by name"
	local data=$(sql_config_get_json $IK_DB_COLLECTION "$sql_show")

	#所有wan口带宽的平均使用率
	local sql_show="select round(avg(cast(upload_use as float)),2) as upload,round(avg(cast(download_use as float)),2) as download from bandwidth_stat $sql_rdays_param"
	local res=$(sql_config_get_list $IK_DB_COLLECTION "$sql_show")
	[ -n "$res" ] && {
		local $res
		upload=${upload:-0}
		download=${download:-0}
		local data_avg=$(json_output  upload:int download:int)
	}
	local bandwidth_stat
	json_append bandwidth_stat data:json data_avg:json

	rm -rf $BANDWIDTH_STAT_CACHE/"$dtype"_*
	echo "$bandwidth_stat" >$BANDWIDTH_STAT_CACHE/"$dtype"_"$current_date"
}

__get_wan_bandwidth() {
        table_name="$1"
        local sql_show
        if [ "$table_name" == "wan_config" ] ;then
                sql_show="select upload,download from $table_name where name='$interface' and internet <= 2"
        else
                sql_show="select upload,download from $table_name where vlan_name='$interface' and enabled='yes'"
        fi
        local res=$(sql_config_get_list $IK_DB_CONFIG "$sql_show")
        [ -n "$res" ] && {
                local $res
		upload_use=$(echo "$now_upload $upload" |awk '{used=($1*100)/$2;if(used>100) used=100;if(used<0) used=0;printf "%d",used}')
		download_use=$(echo "$now_download $download" |awk '{used=($1*100)/$2;if(used>100) used=100;if(used<0) used=0;printf "%d",used}')
                timestamp=$(date +%s)
                echo "insert into bandwidth_stat(timestamp,name,upload_use,download_use) values($timestamp,'$interface','$upload_use','$download_use');" >>/tmp/collection.temp.conf
        }
}

#获取每个wan口的带宽利用率
get_bandwidth_stat() {
        cat /tmp/iktmp/monitor-ikstat/iface|awk '{print "interface="$1,"now_upload="$2,"now_download="$3}'|while read config; do
                if [ -n "$config" ];then
                        local $config
                        __get_wan_bandwidth wan_config
                        __get_wan_bandwidth wan_vlan
                fi
        done
	if [ ! -d "$BANDWIDTH_STAT_CACHE" ];then
		mkdir -p $BANDWIDTH_STAT_CACHE
	fi
	local current_recent_day=$(date "+%F-%H")
	local current_date
	if [ ! -e "$BANDWIDTH_STAT_CACHE/day_$current_recent_day" ]; then
		current_date=$current_recent_day
		__cache_bandwidth_stat day &
	fi
	current_date=$(date +%F)
	if [ ! -e "$BANDWIDTH_STAT_CACHE/week_$current_date" ]; then
		__cache_bandwidth_stat week &
	fi
	if [ ! -e "$BANDWIDTH_STAT_CACHE/month_$current_date" ]; then
		__cache_bandwidth_stat month &	
	fi
}

get_ac_stat() {
	local ap_info=""
	local tempfile=$(
	awk -v apname_file="/tmp/iktmp/apname" '
		BEGIN {
		# 从 wum -c wtps 读状态与性能数据
		while ("wum -c wtps 2>/dev/null" | getline) {
			apmac = $2
			ap_status[apmac] = 1
			ap_cpuuse[apmac] = $18
			chutil_2g[apmac] = $26
			chutil_5g[apmac] = $28
			channf_2g[apmac] = $27
			channf_5g[apmac] = $29
		}
		close("wum -c wtps 2>/dev/null")

		# 读取备注文件
		while ((getline < apname_file) > 0) {
			comment[$1] = $2
		}
		close(apname_file)
	}

	{
		apmac = $1
		s = (ap_status[apmac] ? 1 : 0)
		printf "apmac=%s ap_status=%s ap_cpuuse=%s chutil_2g=%s chutil_5g=%s channf_2g=%s channf_5g=%s comment=%s\n", \
			apmac, s, ap_cpuuse[apmac], chutil_2g[apmac], chutil_5g[apmac], channf_2g[apmac], channf_5g[apmac], comment[apmac]
	}' < <(ls /tmp/iktmp/cache/config/AC/config)
	)

	while read config; do
		[ "$config" ] || continue
		local $config
		[ "$apmac" ] || continue
		local config
		if [ "$chutil_2g" = "" ] || [ "$chutil_2g" = "--" ]; then
			chutil_2g=0
		fi
		if [ "$chutil_5g" = "" ] || [ "$chutil_5g" = "--" ]; then
			chutil_5g=0
		fi
		local chutil_2g_tmp=$((chutil_2g*100/255))
		local chutil_5g_tmp=$((chutil_5g*100/255))

		if [ "$channf_2g" = "" ] || [ "$channf_2g" = "--" ]; then
			channf_2g="-200"
		fi
		if [ "$channf_5g" = "" ] || [ "$channf_5g" = "--" ]; then
			channf_5g="-200"
		fi
		echo "replace into ap_stat_info values(NULL,$timestamp,'$apmac',$ap_status,'$ap_cpuuse',$chutil_2g,$chutil_5g,$channf_2g,$channf_5g);" >> /tmp/warn_info.temp.conf
	done <<EOF
	$tempfile
EOF
}



#获取每分钟各种协议类型的总流量
__get_app_flow_total()
{
	#格式化数据库文件
	cp /proc/ikuai/stats/ik_proto_stats $TMP_DIR/new/

	awk -v timestamp="$timestamp" -v proto_file="$TMP_DIR/old/ik_proto_stats" '
	BEGIN {
		while("cat "proto_file|getline) {
			a[$1] = $2
			b[$1] = $3
			c[$1] = $4
			d[$1] = $5
			e[$1] = $6
		}
	}
	{
		if(FNR==1){
			column="id,timestamp"
			values="NULL,"timestamp
		};

		old_up_value    = d[$1]
		old_down_value  = e[$1]
	
		column=column","$1 ;
		up_value   = $5 < old_up_value   ? $5 : $5-old_up_value
		down_value = $6 < old_down_value ? $6 : $6-old_down_value
		values=values","up_value+down_value
	}
	END{
		printf "insert into app_flow(%s) values(%s);\n", column,values;
	}' $TMP_DIR/new/ik_proto_stats >>/tmp/collection.temp.conf 2>/dev/null
}

#获取每分钟协议的峰值速率
__get_app_flow_up_down()
{
	local data_type="$1" 
lua<<EOF
	cjson = require "cjson"

	type = "$data_type"
	fp = io.popen("socat UNIX-CONNECT:/var/run/ik_stats_collect.sock - </dev/null ")
	
	if fp then
		json_str=fp:read("*a")
		fp:close()
	else
		os.exit(1)
	end
	res, json_tab = pcall(cjson.decode, json_str)
	if not res then
		os.exit(1)
	end
	timestamp = os.time()
	timestamp = timestamp - timestamp%60

	max_total = 0
	max_index = #json_tab
	
	--只取最近的1分钟数据,查找峰值
	for i = #json_tab, #json_tab-19, -1 do
		total = json_tab[i][12].upload + json_tab[i][12].download
		if total > max_total then
			max_total = total
			max_index = i
		end
	end

	if type == "wan_max_bandwidth" then
		print(json_tab[max_index][12].upload, json_tab[max_index][12].download)
		os.exit(0)
	end
	
	
	columns_up_down_app_flow = "id,timestamp"
	values_up_down_app_flow = "NULL,"..timestamp

	for j = 1, 12, 1 do
		name = json_tab[max_index][j].name
		download = json_tab[max_index][j].download
		upload = json_tab[max_index][j].upload

		name = name.."_down"..","..name.."_up"
		value = download..","..upload
		columns_up_down_app_flow = string.format("%s,%s", columns_up_down_app_flow, name)
		values_up_down_app_flow = string.format("%s,%s", values_up_down_app_flow, value)
	end
	up_down_app_flow_sql = string.format("insert into up_down_app_flow(%s) values(%s);", columns_up_down_app_flow, values_up_down_app_flow)

	print(up_down_app_flow_sql)	
EOF
}

ik_app_flow_stat()
{
	__get_app_flow_up_down >> /tmp/collection.temp.conf
	__get_app_flow_total
}

ik_wans_stat()
{
	ik_wans_speed_drops >> /tmp/collection.temp.conf
}
ik_wans_speed_drops() {
	#TODO:保留24小时数据
lua<<EOF
	local str_format = string.format
	local sqlite3 = require "lsqlite3"
	local stats_file = "$TMP_DIR/old/dev"
	local last_time_file = "$TMP_DIR/last_timestamp"
	local last_time_file_tmp = "$TMP_DIR/last_timestamp.tmp"
	local timenow = os.time()
	local timenow = timenow - timenow%60
	local time_5min_cur = timenow - timenow%300
	local wans_list = {}

	function get_last_timestamp()
		local last_timestamp=0
		local f,err = io.open(last_time_file)
		if f then
			last_timestamp=f:read("*l")
			f:close()
		end
		return tonumber(last_timestamp) or 0
	end
	function update_last_timestamp(timestamp)
		local last_timestamp=0
		local f,err = io.open(last_time_file_tmp, "w")
		if f then
			f:write(timestamp)
			f:close()
		end
		os.rename(last_time_file_tmp, last_time_file)
	end

	function collect_5min_status(time_5min_cur)
		local last_timestamp = get_last_timestamp()
		if last_timestamp > time_5min_cur then
			-- System time rollback may leave a future timestamp in cache.
			-- Move it back one bucket so aggregation can resume immediately.
			last_timestamp = time_5min_cur - 300
			if last_timestamp < 0 then
				last_timestamp = 0
			end
			update_last_timestamp(last_timestamp)
		end
		if last_timestamp ~= 0 and time_5min_cur > last_timestamp then
			local ikdb = sqlite3.open('$IK_DB_COLLECTION')
			if ikdb then
				local sql=str_format("select (timestamp/300)*300 as timestamp ,interface,round(avg(upload),2) as avg_upload,round(avg(download),2) as avg_download, round(avg(rtt),2) as avg_rtt, max(upload) as max_upload, max(download) as max_download, max(rtt) as max_rtt, min(rtt) as min_rtt,round(sum(total_drops)/sum(total_packges)*100,2) as drop_rate from wans_stat where timestamp < %u and timestamp >= %u group by interface",time_5min_cur, time_5min_cur-300)
				--print(sql)
				for row in ikdb:nrows(sql) do
					local sql_5min = str_format("insert into wans_stat_5min (timestamp,interface,avg_upload,avg_download,max_upload,max_download,drop_rate,avg_rtt,max_rtt,min_rtt) values(%u,'%s','%.2f','%.2f','%.2f','%.2f','%.2f','%.2f','%.2f','%.2f');",row.timestamp, row.interface, row.avg_upload, row.avg_download, row.max_upload, row.max_download, row.drop_rate or 0, row.avg_rtt, row.max_rtt, row.min_rtt)
					print(sql_5min)
				end

				sql=str_format("select (timestamp/300)*300 as timestamp,'all' as interface, round(avg(upload),2) as avg_upload,round(avg(download),2) as avg_download, round(avg(avg_rtt),2) as avg_rtt, max(upload) as max_upload, max(download) as max_download, max(max_rtt) as max_rtt, min(min_rtt) as min_rtt from (select timestamp,SUM(upload) AS upload, SUM(download) AS download, max(rtt) as max_rtt,min(rtt) as min_rtt,round(avg(rtt),2) as avg_rtt FROM wans_stat where timestamp < %u and timestamp >= %u group by (timestamp / 60) * 60) as minute_stats", time_5min_cur, time_5min_cur-300)
				--print(sql)
				for row in ikdb:nrows(sql) do
					if row.timestamp then
						local sql_5min = str_format("insert into wans_stat_5min (timestamp,interface,avg_upload,avg_download,max_upload,max_download,drop_rate,avg_rtt,max_rtt,min_rtt) values(%u,'%s','%.2f','%.2f','%.2f','%.2f','%.2f','%.2f','%.2f','%.2f');",row.timestamp, row.interface, row.avg_upload, row.avg_download, row.max_upload, row.max_download, 0, row.avg_rtt, row.max_rtt, row.min_rtt)
						print(sql_5min)
					end
				end
				ikdb:close()
			end

			update_last_timestamp(time_5min_cur)
			local del_sql = str_format("delete from wans_stat where timestamp<%u;", time_5min_cur)
			print(del_sql)
		elseif last_timestamp == 0 then
			update_last_timestamp(time_5min_cur)
		end
	end
	
	-- 检查接口是否为WAN类型
	function is_wan_interface(dev_name)
	    if not dev_name then return false end
	    
	    if string.sub(dev_name, 1, 3) == "wan" or 
	       string.sub(dev_name, 1, 4) == "vwan" or 
	       string.sub(dev_name, 1, 4) == "adsl" then
	        return true
	    end
	    
	    return false
	end

	function get_wans_list()
	    local f = io.open("/tmp/iktmp/cache/ifname/wan", "r")
	    if not f then 
	        return {}
	    end
	    
	    for line in f:lines() do
		local ifname=line 
		if ifname then
			wans_list[ifname]=true
		end
	    end
	    f:close()
	end
	
	-- 读取/proc/net/dev数据
	function read_proc_net_dev(filename)
	    local f = io.open(filename, "r")
	    if not f then 
	        return {}
	    end
	    
	    -- 跳过前两行标题
	    f:read("*l")
	    f:read("*l")
	    
	    local results = {}
	    for line in f:lines() do
	        -- 解析格式：dev_name: bytes packets errs drop fifo frame compressed multicast|bytes packets errs drop fifo...
	        local dev_name, rx_bytes, rx_packets, rx_errs, rx_drop, tx_bytes, tx_packets, tx_errs, tx_drop = 
	            string.match(line, "^ *([^ ]+): +(%d+) +(%d+) +(%d+) +(%d+) +%d+ +%d+ +%d+ +%d+ +(%d+) +(%d+) +(%d+) +(%d+)")
	        
	        if dev_name and wans_list[dev_name] then
	            results[dev_name] = {
	                rx_packets = tonumber(rx_packets) or 0,
	                rx_drop = tonumber(rx_drop) or 0,
	                tx_packets = tonumber(tx_packets) or 0,
	                tx_drop = tonumber(tx_drop) or 0
	            }
	        end
	    end
	    
	    f:close()
	    return results
	end
	
	-- 读取iface文件中的速率信息
	function read_iface_speeds(filename)
	    local speeds = {}
	    local f = io.open(filename, "r")
	    if not f then return speeds end
	    
	    for line in f:lines() do
	        -- 解析格式：线路名称 上行速率 下行速率 上行总流量 下行总流量
		--print(line)
	        local dev_name, tx_speed, rx_speed = string.match(line, "^([^ ]+) +([%d.]+) +([%d.]+)")
		--print(dev_name, tx_speed, rx_speed)
	        if dev_name and tx_speed and rx_speed and wans_list[dev_name] then
	            speeds[dev_name] = {
	                tx_speed = tonumber(tx_speed),
	                rx_speed = tonumber(rx_speed)
	            }
	        end
	    end
	    
	    f:close()
	    return speeds
	end
	
	-- 读取历史数据
	function read_history(filename)
	    local f = io.open(filename, "r")
	    if not f then return {} end
	    
	    local history = {}
	    for line in f:lines() do
	        local dev_name, rx_packets, rx_drop, tx_packets, tx_drop = 
	            string.match(line, "([^ ]+) +(%d+) +(%d+) +(%d+) +(%d+)")
	        if dev_name then
	            history[dev_name] = {
	                rx_packets = tonumber(rx_packets),
	                rx_drop = tonumber(rx_drop),
	                tx_packets = tonumber(tx_packets),
	                tx_drop = tonumber(tx_drop)
	            }
	        end
	    end
	    
	    f:close()
	    return history
	end
	
	-- 保存历史数据
	function save_history(filename, current_data)
	    local f = io.open(filename, "w")
	    if not f then return end
	    
	    for dev_name, data in pairs(current_data) do
	        f:write(string.format("%s %d %d %d %d\n", 
	                              dev_name, 
	                              data.rx_packets, 
	                              data.rx_drop, 
	                              data.tx_packets, 
	                              data.tx_drop))
	    end
	    
	    f:close()
	end
	--获取线路rtt
	function get_iface_rtt(ifname)
	    local rtt_times = 0
	    local received_packets = 0
	    local timeout_count = 0
	    local total_packets = 0
	    local filename="/tmp/iktmp/monitor-link/"..ifname.."_rtt"
	    local f = io.open(filename, "r")
	    if not f then return nil end
	    for line in f:lines() do
		-- 匹配延迟时间行
		local time_value = line:match("time=([%d%.]+) ms")
		if time_value then
			rtt_times = rtt_times + tonumber(time_value)
			received_packets = received_packets + 1
		-- 匹配超时行
		elseif line:match("Timeout") then
			timeout_count = timeout_count + 1
		-- 匹配统计行获取总包数
		else
			total_packets = line:match("^(%d+) packets transmitted")
		end
	    end
	    f:close()
            if total_packets == 0 then
		total_packets = received_packets + timeout_count
	    end

	    if total_packets == 0 or received_packets == 0 then
		return nil
	    else
		local avg_rtt = rtt_times / received_packets
		return avg_rtt
	    end
	end
	
	-- 主处理逻辑
	function main()
	    -- 读取当前数据
	    collect_5min_status(time_5min_cur)
	    get_wans_list()
	    local current_data = read_proc_net_dev("/proc/net/dev")
	    if next(current_data) == nil then
	        --print("错误：无法读取/proc/net/dev数据或未找到WAN接口")
	        return 1
	    end
	    
	    -- 读取速率信息
	    local iface_speeds = read_iface_speeds("/tmp/iktmp/monitor-ikstat/iface")
	    
	    -- 读取历史数据
	    local history_data = read_history(stats_file)
	    
	    -- 计算统计信息并生成输出
	    local output_lines = {}
	    
	    for dev_name, current_info in pairs(current_data) do
	        local old_info = history_data[dev_name]
	        
	        -- 计算差值
	        local rx_packets_delta = current_info.rx_packets - (old_info and old_info.rx_packets or 0)
	        local tx_packets_delta = current_info.tx_packets - (old_info and old_info.tx_packets or 0)
	        local rx_drops_delta = current_info.rx_drop - (old_info and old_info.rx_drop or 0)
	        local tx_drops_delta = current_info.tx_drop - (old_info and old_info.tx_drop or 0)
	        
	        -- 防止计数器回绕
	        if rx_packets_delta < 0 then rx_packets_delta = 0 end
	        if tx_packets_delta < 0 then tx_packets_delta = 0 end
	        if rx_drops_delta < 0 then rx_drops_delta = 0 end
	        if tx_drops_delta < 0 then tx_drops_delta = 0 end
	        
	        -- 总发包数和丢包数
	        local total_packets = rx_packets_delta + tx_packets_delta
	        local total_drops = rx_drops_delta + tx_drops_delta
	        local total_drop_rate = 0
	        if total_packets > 0 then
	            total_drop_rate = (total_drops / total_packets) * 100
	        end
	        
	        -- 获取速率信息
	        local speed_info = iface_speeds[dev_name]
	        local tx_speed = speed_info and speed_info.tx_speed or 0
	        local rx_speed = speed_info and speed_info.rx_speed or 0

		-- 获取rtt
		local rtt = get_iface_rtt(dev_name)
	        -- 格式：线路名称 1分钟内发包数 1分钟内丢包数 1分钟丢包率 上行速率 下行速率
		local sql = str_format("insert into wans_stat (timestamp,interface,upload,download,total_packges,total_drops,drop_rate,rtt) values(%u,'%s','%.2f','%.2f',%u,%u,'%.2f','%.2f');",timenow, dev_name, tx_speed,rx_speed, total_packets, total_drops, total_drop_rate, rtt or 0)
		print(sql)
	    end
	    
	    -- 保存当前数据作为历史数据
	    save_history(stats_file, current_data)
	    return 0
	end
	
	-- 执行主函数
	os.exit(main())
EOF
}

__limit_ipv6_wan_config()
{
	local limit="$1"
	sqlite3 $IK_DB_CONFIG "update ipv6_wan_config set enabled='no' where id not in (select id from ipv6_wan_config order by id limit $limit)"
	
	$IK_DIR_SCRIPT/ipv6.sh restart >/dev/null 2>&1 &
}

check_ipv6_multi_expires()
{
	local PKG_PATH="/etc/mnt/.ipv6_multi"

	local reset=0
	local count=$(sqlite3 $IK_DB_CONFIG "select count() from ipv6_wan_config where enabled='yes'")
	if [ -e "$PKG_PATH" ]; then
		local res=$(cat $PKG_PATH)
		if [ "$res" ]; then
			local $res
		fi

		if [ "$expires" ]; then
			local now=$(date +%s)
			if [ "$expires" != "0" -a "$now" -ge "$expires" ]; then
				reset=1
			fi 
		else
			reset=1
		fi
		if [ "$reset" = "1" ]; then
			$IK_DIR_SCRIPT/ipv6.sh multi_off >/dev/null 2>&1 &
			return
		fi
		if [ "$num" ]; then
			if [ "$count" -gt "$num" ]; then
				__limit_ipv6_wan_config $num
			fi
		fi
	else
		if [ "$count" -gt "1" ]; then
			$IK_DIR_SCRIPT/ipv6.sh multi_off >/dev/null 2>&1 &
		fi		
	fi

	sleep 2
	if [ ! -e "$PKG_PATH" ]; then
		return
	fi

	local $(cat $PKG_PATH 2>/dev/null)

	##不管企业版本 还是免费版本， 只要远控异常 24小时候后关闭多线IPv6
	##判断远控连接是否正常建立
	local res=$(netstat -atnp | awk '/ik_rc_client/{if($6=="ESTABLISHED")print $0}')
	if [ "$res" ]; then
		rm /etc/mnt/.ipv6_multi_timeout >/dev/null 2>&1
	else
		if [ -e "/etc/mnt/.ipv6_multi_timeout" ]; then
			local $(cat /etc/mnt/.ipv6_multi_timeout 2>/dev/null)

			if [ "$timeout" -gt "1440" ]; then
				$IK_DIR_SCRIPT/ipv6.sh multi_off >/dev/null 2>&1 &
				echo "timeout=0" > /etc/mnt/.ipv6_multi_timeout
			else
				echo "timeout=$((timeout+1))" > /etc/mnt/.ipv6_multi_timeout
			fi
		else
			echo "timeout=1" > /etc/mnt/.ipv6_multi_timeout
		fi
	fi

	return
}

start()
{
	sysstat_get_mem
	sysstat_get_cpu
	TMP_DIR=/tmp/iktmp/collection-stats

	rm -rf  $TMP_DIR/new $TMP_DIR/tmp /tmp/collection.temp.conf
	rm -rf /tmp/extend_collection.temp.conf
	mkdir -m 0755 -p $TMP_DIR/new $TMP_DIR/old $TMP_DIR/tmp

	datetime=$(date +"%F %T")
	timestamp=$(date +%s)
	timestamp=$((timestamp-timestamp%60))
	__ensure_collection_wireless_columns

	#BEGIN
	echo "PRAGMA foreign_keys=OFF;BEGIN TRANSACTION;" >/tmp/collection.temp.conf
	echo "PRAGMA foreign_keys=OFF;BEGIN TRANSACTION;" >/tmp/extend_collection.temp.conf
	echo "PRAGMA foreign_keys=OFF;BEGIN TRANSACTION;" >/tmp/warn_info.temp.conf

	#清除过期数据
	clean
	#wifi认证信息统计
	terminal_record
	webauth_count
	#系统状态数据
	system_stats
	#统计网卡协议流量
	ik_app_flow_stat
	#统计网卡速率和丢包
	ik_wans_stat
	#用户上下线记录统计
	load_ik_event
	#统计ikuai DNS 缓存
	ik_dns_cache_stat
	#统计wan口带宽使用率
#	get_bandwidth_stat
	ik_cache_lan_prefix_addr

	#ap信道利用率和底噪用于告警
	get_ac_stat
	#END
	echo "COMMIT;" >>/tmp/collection.temp.conf
	echo "COMMIT;" >>/tmp/extend_collection.temp.conf
	echo "COMMIT;" >>/tmp/warn_info.temp.conf

	#导入采集库
	sqlite3 /etc/log/collection.db  </tmp/collection.temp.conf
	sqlite3 /etc/log/warn_info.db  </tmp/warn_info.temp.conf
	if [ -e "$EXTEND_WORK_DIR/collection.db" ]; then
		sqlite3 $EXTEND_WORK_DIR/collection.db  </tmp/extend_collection.temp.conf
	fi
	rm -rf  $TMP_DIR/old $TMP_DIR/tmp #/tmp/collection.temp.conf
	mv $TMP_DIR/new $TMP_DIR/old
	
	#
	client_type
	check_ipv6_multi_expires >/dev/null 2>&1 &
}

#获取cpu温度
__get_cpu_temp()
{
	declare -A cpu_temp
	local filedir="/tmp/iktmp/cputemp"
	local i=0
	for file in $(ls $filedir) ;do
		local temp=$(cat $filedir/$file 2>/dev/null)
		if [[ "$temp" =~ ^[0-9]+$ ]] ;then
			cpu_temp[$i]=$((temp/1000))
		fi
		((i++))
	done
	echo "${cpu_temp[@]}"
	unset cpu_temp
}

#获取外网收/发包统计
__get_wan_packages()
{
luajit <<EOF

	f = io.open("/proc/net/dev")
	if not f then
		print(0,0)
		os.exit()
	end

	fp = io.popen("brctl show")
	if not fp then
		print(0,0)
		os.exit()
	end

	local ffi = require "ffi"
	ffi.cdef [[
		unsigned long long int strtoull(const char *nptr, char **endptr, int base);
	]]
	local strtoull = ffi.C.strtoull

	local function ikL_strtoull(str)
		local str = tostring(str)
		return strtoull(str,nil,10)
	end

	RxPackets = {}
	TxPackets = {}

	for line in f:lines() do
		interface, 
		rx_bytes, rx_packets, rx_errs, rx_drop, rx_fifo, rx_frame, rx_compressed, rx_multicast, 
		tx_bytes, tx_packets, tx_errs, tx_drop, tx_fifo, tx_colls, tx_carrier, tx_compressed 
		= line:match("^ *(v?eth[0-9]+): +(%d+) +(%d+) +(%d+) +(%d+) +(%d+) +(%d+) +(%d+) +(%d+) +(%d+) +(%d+) +(%d+) +(%d+) +(%d+) +(%d+) +(%d+) +(%d+)")

		if interface then
			RxPackets[interface] = rx_packets
			TxPackets[interface] = tx_packets
		end
	end
	f:close()

	TotalRx = 0
	TotalTx = 0

	for line in fp:lines() do
		local _, interface = line:match("^(wan[0-9]+)\t[^ ]+\t[^ ]+\t([^ ]+)")
		if interface and string.match(interface, "bondw") then
			local filename = "/sys/class/net/" .. interface .. "/bonding/slaves"
			local fbw = io.open(filename)
			local data
			if fbw then
				data = fbw:read("*l")
				fbw:close()
			end
			local eth_table
			if data then
				local ikutils = require "iklua.utils"
				local split = ikutils.split
				eth_table = split(data, " ")	
			end

			if eth_table then
				for k,v in ipairs(eth_table) do
					TotalRx = string.format("%u",RxPackets[v] + TotalRx)
					TotalTx = string.format("%u",TxPackets[v] + TotalTx)
				end
			end

		else
			if interface and RxPackets[interface] then
				TotalRx = string.format("%u",RxPackets[interface] + TotalRx)
				TotalTx = string.format("%u",TxPackets[interface] + TotalTx)
			end
		end
	end
	fp:close()

	f = io.open("/tmp/iktmp/rxtx_packages")
	if f then
		line = f:read("*l")
		OldTotalTx, OldTotalRx = line:match("(%d+) (%d+)")
		f:close()
	end

	TotalTx = ikL_strtoull(TotalTx)
	TotalRx = ikL_strtoull(TotalRx)
	if OldTotalTx then
		OldTotalTx = ikL_strtoull(OldTotalTx)
		OldTotalRx = ikL_strtoull(OldTotalRx)
		
		if OldTotalTx > TotalTx then 
			TotalTxDiff = TotalTx
		else
			TotalTxDiff = TotalTx-OldTotalTx
		end

		if OldTotalRx > TotalRx then
			TotalRxDiff = TotalRx
		else
			TotalRxDiff = TotalRx-OldTotalRx
		end
	else
		TotalTxDiff = TotalTx
		TotalRxDiff = TotalRx
	end

	f = io.open("/tmp/iktmp/rxtx_packages","w")
	if f then
		local strbuf = string.format("%s %s", tostring(TotalTx):match("%d+"), tostring(TotalRx):match("%d+"))
		f:write(strbuf)
		f:close()
	end

	print(tostring(TotalTxDiff):match("%d+"), tostring(TotalRxDiff):match("%d+"))


EOF
}

__get_terminal_online_time_ipv4()
{
luajit <<EOF
	local dbfile="$1"
	local skip_vpn="$2"
	str_match = string.match
	str_format = string.format
	local sqlite3 = require "lsqlite3"
	local cjson = require "cjson"

	local timenow = os.time()
	local timenow = timenow - timenow%60
	local vpn_str = "l2tp,pptp,ike,ovpn,pppoe"

	offline_table="offline_record"
	offline_table_vpn="offline_record_vpn"
	daytime_table="daytime_record"
	daytime_table_vpn="daytime_record_vpn"
	host_table="host_record"

	local datetime = os.date("%Y %m %d")
	local year, month, day = string.match(datetime, "([^ ]+) ([^ ]+) ([^ ]+)")
	local t = {year=year, month=month, day=day, hour=0, min=0, sec=0}
	local daytime=os.time(t)

	local baseinfo = {}	
	local baseinfo_ip = {}	
	local function load_baseinfo(daytime, dt_table)
		local info = {}	
		local ikdb = sqlite3.open(dbfile)
		if ikdb then
			ikdb:busy_timeout(10000)
		else
			return info
		end
		local sql=str_format("select id,mac,timestamp,base_total_up,base_total_down from %s where daytime=%s", dt_table, daytime)
		for row in ikdb:nrows(sql) do
			if not info[row.mac] then
				info[row.mac] = {}
			end
			table.insert(info[row.mac], row)
		end
		ikdb:close()
		return info
	end

	local function get_baseinfo(info, mac, timestamp)
		local macinfo = {}

		if not info[mac] then
			return nil,nil,nil
		end
		for k,v in ipairs(info[mac]) do
			if tonumber(v.timestamp) == tonumber(timestamp) then
				macinfo = v
				break
			end	
		end
		return macinfo.id or nil,macinfo.base_total_up or nil,macinfo.base_total_down or nil
	end
	--vpn使用带ip的
	local function load_baseinfo_ip(daytime, dt_table)
		local info = {}
		local ikdb = sqlite3.open(dbfile)
		if ikdb then
			ikdb:busy_timeout(10000)
		else
			return info
		end
		local sql=str_format("select id,mac,ip_addr,timestamp,base_total_up,base_total_down from %s where daytime=%s", dt_table, daytime)
		for row in ikdb:nrows(sql) do
			if not info[row.mac] then
				info[row.mac] = {}
				info[row.mac][row.ip_addr] = {}
			else
				if not info[row.mac][row.ip_addr] then
					info[row.mac][row.ip_addr] = {}
				end
			end
			table.insert(info[row.mac][row.ip_addr], row)
		end
		ikdb:close()
		return info
	end

	local function get_baseinfo_ip(info, mac, timestamp,ip)
		local macinfo = {}

		if not info[mac] then
			return nil,nil,nil
		end
		if not info[mac][ip] then
			return nil,nil,nil
		end

		for k,v in ipairs(info[mac][ip]) do
			if tonumber(v.timestamp) == tonumber(timestamp) then
				macinfo = v
				break
			end
		end
		return macinfo.id or nil,macinfo.base_total_up or nil,macinfo.base_total_down or nil
	end

	local ff
	local is_vpn = 0
	local baseinfo = load_baseinfo(daytime,daytime_table)
	local baseinfo_ip = load_baseinfo_ip(daytime,daytime_table_vpn)
	ff = io.popen('iktimerc ".load_hosts_max; select ip_addr,mac,total_up,total_down,auth_type,ppptype,username,client_type,client_vendor,client_model,client_typeid,timestamp,dtalk_name,vlan_id,today_total,ipv4_gnames,ipv6_gnames,mac_gnames,termname,frequencies,apmac,bssid,ssid,comment from online_user"')
	if ff then
		local tday_f, err = io.open('${today_total_file_tmp}', "a")
		for line in ff:lines() do
			local ip,mac,total_up,total_down,auth_type,ppptype,username,systype,devtype,client_model,client_typeid,timestamp,dtalk_name,vlan_id,today_total,ipv4_gnames,ipv6_gnames,mac_gnames,termname,frequencies,apmac,bssid,ssid,comment = str_match(line, "^ip_addr=([^ ]+) mac=([^ ]+) total_up=([^ ]+) total_down=([^ ]+) auth_type=([^ ]+) ppptype=([^ ]*) username=([^ ]*) client_type=([^ ]+) client_vendor=([^ ]+) client_model=([^ ]*) client_typeid=([^ ]+) timestamp=([^ ]+) dtalk_name=([^ ]*) vlan_id=([^ ]+) today_total=([^ ]+) ipv4_gnames=([^ ]*) ipv6_gnames=([^ ]*) mac_gnames=([^ ]*) termname=([^ ]*) frequencies=([^ ]*) apmac=([^ ]*) bssid=([^ ]*) ssid=([^ ]*) comment=(.*)")
			is_vpn = 0	
			if mac and not mac:match("00:00:00:00:00:00") then
			--if mac and tonumber(total_up) > 0 and tonumber(total_down) > 0 and tonumber(timestamp) <= timenow and not mac:match("00:00:00:00:00:00") then
				local mac_addr = mac
				if ppptype and ppptype ~= "" and string.find(vpn_str,ppptype) then
					mac = username
					is_vpn=1
					if skip_vpn == "1" then
						goto continue
					end
				end
				local base_total_up = 0
				local base_total_down = 0
				if tonumber(daytime) == tonumber(timenow) then
					base_total_up = total_up
					base_total_down = total_down
					base_id = "NULL"
				else
					if is_vpn == 1 then
						base_id, base_up, base_down = get_baseinfo_ip(baseinfo_ip, mac, timestamp, ip)
					else
						base_id, base_up, base_down = get_baseinfo(baseinfo, mac, timestamp)
					end
					if base_id and base_up and base_down then
						base_total_up = base_up
						base_total_down = base_down	
					else
						base_id = "NULL"
					end	
				end

				local daytime_online = 0
				if tonumber(timestamp) < tonumber(daytime) then
					daytime_online = timenow - daytime
				else
					daytime_online = timenow - timestamp
				end
				if daytime_online < 0 then
					daytime_online = 0
				end
				if is_vpn == 1 then
					sql = str_format("replace into %s(id,timestamp,logout_time,online_time,ip_addr,mac,mac_addr,total_up,total_down,auth,systype,devtype,client_model,client_typeid,dtalk_name,vlan_id,today_total,ipv4_gnames,ipv6_gnames,mac_gnames,username,comment,termname) values((select id from %s where timestamp=%u and mac='%s' and ip_addr='%s'),%s,%s,%u,'%s','%s','%s','%s','%s',%d,'%s','%s','%s',%u,'%s',%s,%s,'%s','%s','%s','%s','%s','%s');", offline_table_vpn, offline_table_vpn, timestamp,mac, ip,timestamp, timenow, timenow-timestamp, ip, mac, mac_addr, total_up, total_down,  auth_type, systype, devtype, client_model, client_typeid, dtalk_name,vlan_id,today_total,ipv4_gnames,ipv6_gnames,mac_gnames,username,comment, termname)
					sql_day = str_format("replace into %s(id,timestamp,logout_time,daytime,online_time,ip_addr,mac,mac_addr,base_total_up,base_total_down,total_up,total_down,auth,systype,devtype,comment) values(%s,'%s','%s',%u,%u,'%s','%s','%s','%s','%s','%s','%s',%d,'%s','%s','%s' );", daytime_table_vpn, base_id, timestamp, timenow, daytime, daytime_online, ip, mac,mac_addr, base_total_up, base_total_down, total_up, total_down,  auth_type, systype, devtype, comment)

				else
					sql = str_format("replace into %s(id,timestamp,logout_time,online_time,ip_addr,mac,total_up,total_down,auth,systype,devtype,client_model,client_typeid,dtalk_name,vlan_id,today_total,ipv4_gnames,ipv6_gnames,mac_gnames,username,comment,termname,frequencies,apmac,bssid,ssid) values((select id from %s where timestamp=%u and mac='%s'),%s,%s,%u,'%s','%s',%s,%s,%d,'%s','%s','%s',%u,'%s',%s,%s,'%s','%s','%s','%s','%s','%s','%s','%s','%s','%s' );", offline_table, offline_table, timestamp,mac, timestamp, timenow, timenow-timestamp, ip, mac, total_up, total_down,  auth_type, systype, devtype, client_model, client_typeid, dtalk_name,vlan_id,today_total,ipv4_gnames,ipv6_gnames,mac_gnames,username,comment,termname,frequencies or "",apmac or "",bssid or "",ssid or "")

					sql_day = str_format("replace into %s(id,timestamp,logout_time,daytime,online_time,ip_addr,mac,base_total_up,base_total_down,total_up,total_down,auth,systype,devtype,comment) values(%s,%s,%s,%u,%u,'%s','%s',%s,%s,%s,%s,%d,'%s','%s','%s' );", daytime_table, base_id, timestamp, timenow, daytime, daytime_online, ip, mac, base_total_up, base_total_down, total_up, total_down,  auth_type, systype, devtype, termname)
					--TODO:只处理非vpn，写入缓存文件

					if tday_f then
						tday_f:write(string.format("%s %u\n",mac, today_total))
					end
				end

				if host_table then
					sql_host = str_format("replace into %s(timestamp,logout_time,ip_addr,mac,auth,systype,devtype,client_model,client_typeid,comment) values(%u,%u,'%s','%s',%d,'%s','%s','%s',%u,'%s');", host_table, timestamp, timenow, ip, mac, auth_type, systype, devtype, client_model, client_typeid, comment)
					print(sql_host)
				end

				print(sql)
				print(sql_day)
			end
			::continue::
		end
		ff:close()
		if tday_f then
			tday_f:close()
		end
	end
EOF
}
__get_terminal_online_time_ipv6()
{
luajit <<EOF
	local dbfile="$1"
	str_match = string.match
	str_format = string.format
	local sqlite3 = require "lsqlite3"
	local cjson = require "cjson"

	local timenow = os.time()
	local timenow = timenow - timenow%60

	offline_table="offline_record6"
	daytime_table="daytime_record6"

	local datetime = os.date("%Y %m %d")
	local year, month, day = string.match(datetime, "([^ ]+) ([^ ]+) ([^ ]+)")
	local t = {year=year, month=month, day=day, hour=0, min=0, sec=0}
	local daytime=os.time(t)

	local baseinfo = {}	

	local function load_baseinfo_ipv6(daytime, dt_table)
		local info = {}
		local ikdb = sqlite3.open(dbfile)
		if ikdb then
			ikdb:busy_timeout(10000)
		else
			return info
		end
		local sql=str_format("select id,mac,ip_addr,timestamp,base_total_up,base_total_down from %s where daytime=%s", dt_table, daytime)
		for row in ikdb:nrows(sql) do
			if not info[row.mac] then
				info[row.mac] = {}
				info[row.mac][row.ip_addr] = {}
			else
				if not info[row.mac][row.ip_addr] then
					info[row.mac][row.ip_addr] = {}
				end
			end
			table.insert(info[row.mac][row.ip_addr], row)
		end
		ikdb:close()
		return info
	end

	local function get_baseinfo_ipv6(info, mac, timestamp,ip)
		local macinfo = {}

		if not info[mac] then
			return nil,nil,nil
		end
		if not info[mac][ip] then
			return nil,nil,nil
		end

		for k,v in ipairs(info[mac][ip]) do
			if tonumber(v.timestamp) == tonumber(timestamp) then
				macinfo = v
				break
			end
		end
		return macinfo.id or nil,macinfo.base_total_up or nil,macinfo.base_total_down or nil
	end


	local ff
	local baseinfo = load_baseinfo_ipv6(daytime,daytime_table)
	ff = io.popen('iktimerc ".load_hosts6_max; select ip_addr,mac,total_up,total_down,auth_type,ppptype,username,client_type,client_vendor,client_model,client_typeid,timestamp,dtalk_name,vlan_id,today_total,ipv4_gnames,ipv6_gnames,mac_gnames,termname,frequencies,apmac,bssid,ssid,comment from online_user"')
	if ff then
		local tday_f, err = io.open('${today_total_file_tmp}', "a")
		for line in ff:lines() do
			local ip,mac,total_up,total_down,auth_type,ppptype,username,systype,devtype,client_model,client_typeid,timestamp,dtalk_name,vlan_id,today_total,ipv4_gnames,ipv6_gnames,mac_gnames,termname,frequencies,apmac,bssid,ssid,comment = str_match(line, "^ip_addr=([^ ]+) mac=([^ ]+) total_up=([^ ]+) total_down=([^ ]+) auth_type=([^ ]+) ppptype=([^ ]*) username=([^ ]*) client_type=([^ ]+) client_vendor=([^ ]+) client_model=([^ ]*) client_typeid=([^ ]+) timestamp=([^ ]+) dtalk_name=([^ ]*) vlan_id=([^ ]+) today_total=([^ ]+) ipv4_gnames=([^ ]*) ipv6_gnames=([^ ]*) mac_gnames=([^ ]*) termname=([^ ]*) frequencies=([^ ]*) apmac=([^ ]*) bssid=([^ ]*) ssid=([^ ]*) comment=(.*)")
			if mac and not mac:match("00:00:00:00:00:00") then
			--if mac and tonumber(total_up) > 0 and tonumber(total_down) > 0 and tonumber(timestamp) <= timenow and not mac:match("00:00:00:00:00:00") then
				local base_total_up = 0
				local base_total_down = 0
				if tonumber(daytime) == tonumber(timenow) then
					base_total_up = total_up
					base_total_down = total_down
					base_id = "NULL"
				else
					base_id, base_up, base_down = get_baseinfo_ipv6(baseinfo, mac, timestamp, ip)
					if base_id and base_up and base_down then
						base_total_up = base_up
						base_total_down = base_down	
					else
						base_id = "NULL"
					end	
				end

				local daytime_online = 0
				if tonumber(timestamp) < tonumber(daytime) then
					daytime_online = timenow - daytime
				else
					daytime_online = timenow - timestamp
				end
				if daytime_online < 0 then
					daytime_online = 0
				end
				sql = str_format("replace into %s(id,timestamp,logout_time,online_time,ip_addr,mac,total_up,total_down,auth,systype,devtype,client_model,client_typeid,dtalk_name,vlan_id,today_total,ipv4_gnames,ipv6_gnames,mac_gnames,username,comment,termname,frequencies,apmac,bssid,ssid) values((select id from %s where timestamp=%u and mac='%s' and ip_addr='%s'),%s,%s,%u,'%s','%s',%s,%s,%d,'%s','%s','%s',%u,'%s',%s,%s,'%s','%s','%s','%s','%s','%s','%s','%s','%s','%s');", offline_table, offline_table, timestamp,mac, ip,timestamp, timenow, timenow-timestamp, ip, mac, total_up, total_down,  auth_type, systype, devtype, client_model, client_typeid, dtalk_name,vlan_id,today_total,ipv4_gnames,ipv6_gnames,mac_gnames,username,comment,termname,frequencies or "",apmac or "",bssid or "",ssid or "")
				sql_day = str_format("replace into %s(id,timestamp,logout_time,daytime,online_time,ip_addr,mac,base_total_up,base_total_down,total_up,total_down,auth,systype,devtype,comment) values(%s,%s,%s,%u,%u,'%s','%s',%s,%s,%s,%s,%d,'%s','%s','%s' );", daytime_table, base_id, timestamp, timenow, daytime, daytime_online, ip, mac, base_total_up, base_total_down, total_up, total_down,  auth_type, systype, devtype, termname)
				--TODO:写入缓存文件
				if tday_f then
					tday_f:write(string.format("%s %u\n",mac, today_total))
				end

				print(sql)
				print(sql_day)
			end
		end
		ff:close()
		if tday_f then
			tday_f:close()
		end
	end
EOF
}

#终端在线纪录(由老的终端上/下线记录的升级版)
terminal_record()
{
#	[ ! -f /tmp/iktmp/audit.open_terminal_record ]&& return
	if [ -e "$EXTEND_WORK_DIR" ]; then
		local tmpfile="/tmp/extend_collection.temp.conf"
		local dbfile="$EXTEND_WORK_DIR/collection.db"
	else
		local tmpfile="/tmp/collection.temp.conf"
		local dbfile="$IK_DIR_LOG/collection.db"
	fi
	#__get_terminal_online_time "$dbfile" "ipv4" >> $tmpfile
	local skip=0
	if [  "$ARCH" = "x86" -a -z "$ENTERPRISE" ]; then
		skip=1
	fi
	if [ "$OEMNAME" ]; then
		skip=0
	fi
	#TODO:内测暂时都不做限制
	skip=0
	> $today_total_file_tmp
	__get_terminal_online_time_ipv4 "$dbfile" "$skip">> $tmpfile
	if [ "$skip" = "0" ]; then
		__get_terminal_online_time_ipv6 "$dbfile" >> $tmpfile
	fi

	mv $today_total_file_tmp $today_total_file
	#检查是否达到每日限额，如果达到禁止上网
	$IK_DIR_SCRIPT/flow_control.sh check_flow_control_limit $today_total_file
}

webauth_count()
{
	local auth_count=0
	if [ -f /tmp/iktmp/webauth_count/authmac ];then
		mv /tmp/iktmp/webauth_count/authmac /tmp/iktmp/webauth_count/authmac.tmp
		auth_count=$(cat /tmp/iktmp/webauth_count/authmac.tmp|wc -l)
		rm -f /tmp/iktmp/webauth_count/authmac.tmp
	fi

	echo "update every_day_stats set wifi=wifi+$auth_count;" >>/tmp/collection.temp.conf
	#每天统计自动归0
	local date="$(date +%Y%m%d)"
	echo "update every_day_stats set wifi=0,clean_time=$date where clean_time != $date;" >>/tmp/collection.temp.conf
}

__online_user()
{
	awk 'BEGIN{
		sum = 0
		while(getline<"/tmp/iktmp/apmac") apmac[$1]=1
	}{
		if(apmac[$2]!=1)sum++
	}END{
		print sum
	}' /proc/ikuai/stats/host_stats
}

system_stats()
{
	cpu=${SYSSTAT_CPU[0]} #CPU使用率
	memused=$(( ${SYSSTAT_MEM[MemTotal]} - ${SYSSTAT_MEM[MemAvailable]} )) #已使用内存
	memuse=$(( (memused*100)/${SYSSTAT_MEM[MemTotal]} )) #已使用内存百分比
	#terminal=$(__online_user) #在线终端数
	local res=$(sysstat_get_online_user)
	if [ "$res" ];then
		local $res
	else
		local count=0 count_2g=0 count_5g=0
	fi
	local count_wired=$((count-count_2g-count_5g))
	local count_wireless=$((count-count_wired))
	
	disk_space_used=$(df -m |awk '$NF=="/etc/log"{print $3}') ## 已使用磁盘容量
	disk_space_use=$(df -m |awk '$NF=="/etc/log"{print $5}') ## 已使用磁盘百分比

	local updown=($(__get_app_flow_up_down wan_max_bandwidth))
	max_up=${updown[0]}
	max_down=${updown[1]}

	local rxtx_packages=($(__get_wan_packages))
	rx_packages=${rxtx_packages[0]}
	tx_packages=${rxtx_packages[1]}

	local cputemp=($(__get_cpu_temp))
	local cpu0=${cputemp[0]}
	local cpu1=${cputemp[1]}

	local conn_num=$(cat  /proc/sys/net/netfilter/nf_conntrack_count)

	echo "insert into status(id,timestamp,cpu,conn_num,on_terminal,wired_terminal, wireless_terminal, memory,memory_use,disk_space_used,disk_space_use,max_upload,max_download,rx_packages,tx_packages,cputemp1,cputemp2) values(NULL,$timestamp,'${cpu//%}',$conn_num,'$count','$count_wired','$count_wireless','$memused','$memuse','${disk_space_used:-0}','${disk_space_use//%}',${max_up:-0},${max_down:-0},${rx_packages:-0},${tx_packages:-0},${cpu0:-0},${cpu1:-0});" >>/tmp/collection.temp.conf
}

load_ik_event()
{
	#用户上下线记录统计
	if mv /tmp/ik_event_aquisition.conf /tmp/ik_event_aquisition.tmp 2>/dev/null  ;then
		if [ -e "$EXTEND_WORK_DIR" ]; then
			local tmpfile="/tmp/extend_collection.temp.conf"
		else
			local tmpfile="/tmp/collection.temp.conf"
		fi
		cat /tmp/ik_event_aquisition.tmp >> $tmpfile
		rm -f /tmp/ik_event_aquisition.tmp
	fi
}

client_type()
{
	#每天清理客户机类型（ISO、android、windows）
	clean_time=$(cat /etc/log/client_type/clean_time 2>/dev/null)
	if [ "$clean_time" != "${datetime:0:10}" ];then
		rm -f /etc/log/client_type/*
		rm -f /tmp/iktmp/webauth/client_type/*
		echo ${datetime:0:10} > /etc/log/client_type/clean_time
	fi
	awk '{print $13 >"/etc/log/client_type/"$2}'  /proc/ikuai/stats/host_stats 
}


clean()
{
	local now_timestamp=$(date +%s)
	if [[ "${datetime:11:5}" =~ (00|03|06|09|12|15|18|21):00 ]];then
		disk_size=$(df  |awk '$NF=="/etc/log"{print $2}')
		if [ ${disk_size} -gt 300000 ];then
			dateout=$((now_timestamp-31*24*60*60))
		elif [ ${disk_size} -gt 200000 ];then
			dateout=$((now_timestamp-20*24*60*60))
		elif [ ${disk_size} -gt 100000 ];then
			dateout=$((now_timestamp-15*24*60*60))
		elif [ ${disk_size} -gt 50000 ];then
			dateout=$((now_timestamp-10*24*60*60))
		elif [ ${disk_size} -gt 10000 ];then
			dateout=$((now_timestamp-7*24*60*60))
		else
			dateout=$((now_timestamp-24*60*60))
		fi
		if [ "$ARCH" = "arm" ]; then
			local disk_used=$(df  |awk '$NF=="/etc/log"{print $5}')
			local disk_used=${disk_used//%/}
			if [ "$disk_used" -gt "85" ]; then
				dateout=$((now_timestamp-3*24*60*60))
			fi
		fi
		#自定义存储目录的 31天数据
		local extend_dateout=$((now_timestamp-31*24*60*60))
		#删除数据 超过一个月以前的
		echo "delete from status where timestamp < $dateout ;" >>/tmp/collection.temp.conf
		echo "delete from app_flow where timestamp < $dateout ;" >>/tmp/collection.temp.conf
		echo "delete from up_down_app_flow where timestamp < $dateout ;" >>/tmp/collection.temp.conf
		echo "delete from if_app_flow where timestamp < $dateout ;" >>/tmp/collection.temp.conf
		echo "delete from up_down_if_app_flow where timestamp < $dateout ;" >>/tmp/collection.temp.conf
		echo "delete from im_event where timestamp < $dateout ;" >> /tmp/collection.temp.conf
		echo "delete from im_event where timestamp < $extend_dateout ;" >> /tmp/extend_collection.temp.conf
		echo "delete from bandwidth_stat where timestamp<$dateout ;" >>/tmp/collection.temp.conf
		echo "delete from offline_record where logout_time<$dateout ;" >>/tmp/collection.temp.conf
		echo "delete from offline_record_vpn where logout_time<$dateout ;" >>/tmp/collection.temp.conf
		echo "delete from daytime_record where daytime<$dateout ;" >>/tmp/collection.temp.conf
		echo "delete from daytime_record_vpn where daytime<$dateout ;" >>/tmp/collection.temp.conf
		echo "delete from host_record where logout_time<$dateout ;" >>/tmp/collection.temp.conf
		echo "delete from offline_record where logout_time<$extend_dateout ;" >>/tmp/extend_collection.temp.conf
		echo "delete from offline_record_vpn where logout_time<$extend_dateout ;" >>/tmp/extend_collection.temp.conf
		echo "delete from daytime_record where daytime<$extend_dateout ;" >>/tmp/extend_collection.temp.conf
		echo "delete from daytime_record_vpn where daytime<$extend_dateout ;" >>/tmp/extend_collection.temp.conf
		echo "delete from offline_record6 where logout_time<$dateout ;" >>/tmp/collection.temp.conf
		echo "delete from daytime_record6 where daytime<$dateout ;" >>/tmp/collection.temp.conf
		echo "delete from offline_record6 where logout_time<$extend_dateout ;" >>/tmp/extend_collection.temp.conf
		echo "delete from daytime_record6 where daytime<$extend_dateout ;" >>/tmp/extend_collection.temp.conf
		echo "delete from ap_stat_info where timestamp<$dateout ;" >>/tmp/warn_info.temp.conf
		local task_timeout=$((now_timestamp-7*24*60*60))
		sqlite3 /etc/log/task_queue.db "delete from task_queue where timestamp <= $task_timeout"
		local day_timeout=$((now_timestamp-24*60*60))
		echo "delete from wans_stat_5min where timestamp<$day_timeout ;" >>/tmp/collection.temp.conf
	fi
}
