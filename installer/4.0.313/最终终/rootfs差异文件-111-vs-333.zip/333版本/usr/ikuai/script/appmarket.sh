#!/bin/bash /etc/ikcommon
Include interface.sh,ipset.sh,iptables.sh,ipmacgroup.sh,lock.sh,errcode.sh,urlcode.sh,errcode.sh
Include sys/sysstat.sh,fsyslog.sh,check.sh

IK_DB_DOCKER="/etc/mnt/ikuai/docker.db"
IK_DB_APPMARKET="/etc/mnt/ikuai/appmarket.db"
ROOT_PATH="/etc/disk_user/"
APPMARKET_DIR="/var/appmarket/"
APPTMP_DIR="/tmp/iktmp/appmarket"
APPTMPDB="/tmp/iktmp/appmarket/apptmp.db"
SYSTEM_DEFAULT="/etc/log"
NATIVE_APP_SIGN_PUBKEY="/etc/ssl/default/appmarket_plugin_sign_public.pem"

LOCKUP_NB="LockNonblock appmarket"
UNLOCK="unLock appmarket"

LOCKUP_NB_DISKUSED="LockNonblock appmarket_diskused"
UNLOCK_DISKUSED="unLock appmarket_diskused"

LOCKUP_NB_INSTALL="LockNonblock appmarket_install_file"
UNLOCK_INSTALL="unLock appmarket_install_file"

LOCKUP_CACHE="Lock appmarket_cache"
UNLOCK_CACHE="unLock appmarket_cache"

LOCKUP_QUEUE="Lock appmarket_queue"
UNLOCK_QUEUE="unLock appmarket_queue"

PROCESS_CODE_ERR=-1
PROCESS_CODE_SUCCESS=0
PROCESS_CODE_IN_QUEUE=1
PROCESS_CODE_INSTALL_START=2
PROCESS_CODE_DOWNLOAD_PKG=3
PROCESS_CODE_EXTRACT_PKG=4
PROCESS_CODE_DOWNLOAD_IMG=5
PROCESS_CODE_APP_START=6

RUN_CODE_ERR=-1
RUN_CODE_SUCCESS=0
RUN_CODE_START=1

DEFAULT_APPID=100000
MAX_APPID_FILE="/etc/mnt/ikuai/appmarket/.max_appid"
APPMARKET_SHOW_LOG_LINES=200

boot() {
	mkdir -p $APPMARKET_DIR
	mkdir -p $APPTMP_DIR
	mkdir -p $APPTMP_DIR/.pkg
	mkdir -p /etc/mnt/ikuai/appmarket
	mkdir -p /usr/ikuai/www/static/appmarket
	sqlite3 $APPTMPDB < /etc/defaults/apptmp.conf
	clean_upload_cache
	init

	# ==== patch: docker 默认云下发 ====
	# 首次开机(以及每次开机检查)异步触发 docker.sh install;
	# docker.sh install 内部已经做了: 取 GWID、拼 tocken、POST 云端注册安装。
	# 已安装(appmarket.db 有 name=container 行)就直接跳过;
	# GWID 未写入则等 mtd_control.sh / hdd_install.sh 写完。
	(
		mkdir -p /tmp/iktmp/bootlog
		# 等 GWID 最多 5 分钟(每轮从 /etc/release 重新读, GWID 无 export)
		for i in $(seq 1 30); do
			GWID=$(awk -F= '$1=="GWID"{print $2; exit}' /etc/release 2>/dev/null)
			[ -n "$GWID" ] && break
			sleep 10
		done
		[ -n "$GWID" ] || exit 0
		# 已有 container 行? 跳过
		if sqlite3 /etc/mnt/ikuai/appmarket.db "select appid from applist where name='container' limit 1" 2>/dev/null | grep -q .; then
			exit 0
		fi
		$IK_DIR_SCRIPT/docker.sh install >/tmp/iktmp/bootlog/docker_install 2>&1
	) &
}

clean_upload_cache()
{
	local workdisk=$(sqlite3 $IK_DB_DOCKER "select workdisk from global")

	local pkg_path="${ROOT_PATH}${workdisk}/.pkg"

	if [ ! -d "$pkg_path" ]; then
		return 1
	fi

	rm -rf $pkg_path/* 2>/dev/null
}

init() {
	local is_boot="boot"
	
	sync_apps >/dev/null 2>&1 &
	__apps_to_cache
	sql_config_get_list $IK_DB_APPMARKET "select * from applist" \
	|while read config ;do
		if [ -n "$config" ];then
			local $config

			if [ "$type" = "1" ]; then
				local app_path="${ROOT_PATH}${install_path}/apps/$name"
			else
				if [ "$install_path" = "$SYSTEM_DEFAULT" -o "$install_path" = "" ]; then
					local app_path="${SYSTEM_DEFAULT}/apps/$name"
				else
					local app_path="${ROOT_PATH}${install_path}/apps/$name"
				fi
			fi
			__exec_rule_init >/dev/null 2>/dev/null
		fi
	done
}

__exec_rule_init()
{
	if [ ! -e "$APPMARKET_DIR/$name" ]; then
		ln -s $app_path $APPMARKET_DIR/$name
	fi

	if [ -d "${app_path}/.pkg/ui" ]; then
		ln -s ${app_path}/.pkg/ui /usr/ikuai/www/static/appmarket/$name
	fi
	if [ "$type" = "0" ]; then
		__native_app_init
#	else
#		__container_app_init
	fi
}

__check_param_install() {
	check_varl \
		'enabled        == "yes" or == "no"' \
		'appid		!= ""'
}

#磁盘可用空间小于100MB
__check_disk_size()
{
	local dir="$1"

	local dir_arry=(${dir//\// })
	local workpath=$(readlink "$ROOT_PATH/${dir_arry[0]}")

	local available=$(df | awk -v k="$workpath" '{if($6==k){printf "%.0f\n", $4/1024;exit}}')
	local available=${available//\.*/}
	if [ "$available" -a "$available" -lt "100" ]; then
		return 1
	fi
	if [ "$size" ]; then
		local pkg_size=$((100 + size/1024/1024))
		if [ "$pkg_size" -a "$available" -lt "$pkg_size" ]; then
			return 1
		fi
	fi
	return 0
}

#磁盘可用空间小于100MB
__check_system_disk_size()
{
	local available=$(df | awk -v k="/etc/log" '{if($6==k){printf "%.0f\n", $4/1024;exit}}')
	local available=${available//\.*/}
	if [ "$available" -a "$available" -lt "100" ]; then
		return 1
	fi

	if [ "$size" ]; then
		local pkg_size=$((100 + size/1024/1024))
		if [ "$pkg_size" -a "$available" -lt "$pkg_size" ]; then
			return 1
		fi
	fi
	return 0
}

#内存可用空间小于100MB
__check_memory_size()
{
	sysstat_get_mem
	local available="${SYSSTAT_MEM[MemAvailable]}"
	if [ "${available:-0}" -lt "102400" ]; then
		return 1
	fi
	return 0
}

get_next_appid() {
	if [ ! -f "$MAX_APPID_FILE" ]; then
		echo "$DEFAULT_APPID" > "$MAX_APPID_FILE"
		echo "$DEFAULT_APPID"
	else
		local current_appid=$(cat "$MAX_APPID_FILE")
		local next_appid=$((current_appid + 1))
		echo "$next_appid" > "$MAX_APPID_FILE"
		echo "$next_appid"
	fi
}

__check_compose_yaml()
{
	if ! ikluajit $IK_DIR_SCRIPT/sec/docker_security_checker.lua docker-compose.yaml >> $app_path/log/run.log 2>&1; then
		return 1
	fi
	return 0
}

__gen_container_name()
{
	local env_file="$app_path/.pkg/app/.env"
	if [ ! -e "$env_file" ]; then
		return 1
	fi

	local default_dir="/etc/mnt/ikuai/appmarket"
	if [ -e "${default_dir}/$name/environment" ]; then
		cp ${default_dir}/$name/environment $app_path/.pkg/app/environment
	fi

	if [ -e "${default_dir}/$name/default_env" ]; then
		cp ${default_dir}/$name/default_env $app_path/.pkg/app/.env
	fi

	local NAME_NONCE=$(awk -F= '$1 == "NAME_NONCE" {print $2; exit}' "$env_file")
	local IMAGE_VERSION=$(awk -F= '$1 == "IMAGE_VERSION" {print $2; exit}' "$env_file")

	if [ -z "$NAME_NONCE" ]; then
		local nonce_str=$(printf '%s\n' "$name" | md5sum)
		NAME_NONCE=${nonce_str:0:6}
		printf 'NAME_NONCE=%s\n' "$NAME_NONCE" >> "$env_file"
	fi

	local res=$(awk '/container_name:/{print $2;exit}' "$app_path/.pkg/app/docker-compose.yaml")
	local container_name="${res//\$\{NAME_NONCE\}/$NAME_NONCE}"
	if [[ ! "$container_name" =~ ^[A-Za-z0-9][A-Za-z0-9_.-]*$ ]]; then
		return 1
	fi
	printf '%s\n' "$container_name" > "$app_path/.pkg/container_name"

	if [ -z "$IMAGE_VERSION" ]; then
		local image_version=$(cat $app_path/.pkg/manifest.json |jq -r .version)
		echo "IMAGE_VERSION=${image_version:-latest}" >> /var/appmarket/${name}/.pkg/app/.env
	fi

	return 0
}

__gen_native_config()
{
	if [ ! -e "$app_path/.pkg/app/.env" ]; then
		return 1
	fi

	local default_dir="/etc/mnt/ikuai/appmarket"
	if [ -e "${default_dir}/$name/environment" ]; then
		cp ${default_dir}/$name/environment $app_path/.pkg/app/environment
	fi

	if [ -e "${default_dir}/$name/default_env" ]; then
		cp ${default_dir}/$name/default_env $app_path/.pkg/app/.env
	fi
}

__container_app_init()
{
	__container_app_stop
	if [ "$enabled" = "yes" ]; then
		__container_app_start
	fi
	
	return 0
}

__container_app_stop()
{
	cd $app_path/.pkg/app

	if docker-compose down >>$app_path/log/run.log 2>&1; then
		__update_run_log "$app_path" "$RUN_CODE_SUCCESS" "Application stop successfully"
		return 0	
	fi
	__update_run_log "$app_path" "$RUN_CODE_ERR" "Application stop failed"
	return 1
}

__container_app_start()
{
	cd $app_path/.pkg/app
	if ! __check_compose_yaml; then
		__update_run_log "$app_path" "$RUN_CODE_ERR" "Check docker-compose.yaml failed"
		return 1
	fi

#	if [ -x "./scripts/pre_install.sh" ]; then
#		./scripts/pre_install.sh >/dev/null 2>&1 
#	fi

	__gen_container_name
	local exclude="$(cat $app_path/.pkg/container_name)"
	if ! errmsg=$(__is_port_in_use "$exclude"); then
		__update_run_log "$app_path" "$RUN_CODE_ERR" "$errmsg"
		return 1
	fi

	if docker-compose up -d >>$app_path/log/run.log 2>&1; then
		__update_run_log "$app_path" "$RUN_CODE_SUCCESS" "Application started successfully"
		return 0
	fi
	__update_run_log "$app_path" "$RUN_CODE_ERR" "Application started failed"
	return 1
}

__container_app_install()
{
	cd $app_path/.pkg/app

	if ! __check_compose_yaml; then
		__update_run_log "$app_path" "$RUN_CODE_ERR" "Check docker-compose.yaml failed"
		return 1
	fi

#	if [ -x "./scripts/pre_install.sh" ]; then
#		./scripts/pre_install.sh >/dev/null 2>&1 
#	fi

	__gen_container_name
	local exclude="$(cat $app_path/.pkg/container_name)"
	if ! errmsg=$(__is_port_in_use "$exclude"); then
		__update_run_log "$app_path" "$RUN_CODE_ERR" "$errmsg"
		return 1
	fi

	__update_run_log "$app_path" "$RUN_CODE_START" "Application starting"
#	[ -x "../scripts/PRE_INST.sh" ] && ../scripts/PRE_INST.sh >/dev/null 2>&1
	if docker-compose up -d >>$app_path/log/run.log 2>&1; then
#		[ -x "../scripts/POST_INST.sh" ] && ../scripts/POST_INST.sh >/dev/null 2>&1
		__update_run_log "$app_path" "$RUN_CODE_SUCCESS" "Application started successfully"
		return 0
	fi
	__update_run_log "$app_path" "$RUN_CODE_ERR" "Container failed to start. Check container configuration or logs for details."
	return 1
}

__container_app_uninstall()
{
	cd $app_path/.pkg/app

#	[ -x "./scripts/pre_uninstall.sh" ] && ../scripts/pre_uninstall.sh >/dev/null 2>&1

	if docker-compose down  >>$app_path/log/run.log 2>&1; then
#		[ -x "./scripts/POST_UNINST.sh" ] && ../scripts/POST_UNINST.sh >/dev/null 2>&1
		return 0 
	fi
	return 1
}

__native_app_init()
{
	__native_app_stop
	if [ "$enabled" = "yes" ]; then
		__native_app_start
	fi
	return 0
}

__native_app_verify_integrity()
{
	local manifest="$app_path/.pkg/manifest.json"
	local pubkey="$NATIVE_APP_SIGN_PUBKEY"
	local sig_file rel_path expected actual file current_path sig_name

	[ -f "$manifest" ] || {
		echo "Native app integrity check failed: manifest.json not found"
		return 1
	}

	command -v jq >/dev/null 2>&1 || {
		echo "Native app integrity check failed: jq not found"
		return 1
	}

	jq -e '.integrity.files and (.integrity.files | type == "array") and (.integrity.files | length > 0)' "$manifest" >/dev/null 2>&1 || {
		echo "Native app integrity check failed: integrity.files not found"
		return 1
	}

	command -v openssl >/dev/null 2>&1 || {
		echo "Native app integrity check failed: openssl not found"
		return 1
	}

	command -v sha256sum >/dev/null 2>&1 || {
		echo "Native app integrity check failed: sha256sum not found"
		return 1
	}

	[ -f "$pubkey" ] || {
		echo "Native app integrity check failed: public key not found"
		return 1
	}

	sig_name=$(jq -r '.integrity.signature_file // "manifest.json.sig"' "$manifest" 2>/dev/null)
	case "$sig_name" in
		""|/*|*/*|*..*)
			echo "Native app integrity check failed: invalid signature file"
			return 1
			;;
	esac

	sig_file="$app_path/.pkg/$sig_name"
	[ -f "$sig_file" ] || {
		echo "Native app integrity check failed: signature file not found"
		return 1
	}

	if ! openssl dgst -sha256 -verify "$pubkey" -signature "$sig_file" "$manifest" >/dev/null 2>&1; then
		echo "Native app integrity check failed: manifest signature verify failed"
		return 1
	fi

	if jq -e '.integrity.files[] | select((.path | type != "string") or (.sha256 | type != "string"))' "$manifest" >/dev/null 2>&1; then
		echo "Native app integrity check failed: invalid integrity list"
		return 1
	fi

	jq -r '.integrity.files[] | ((.path // "") + "\t" + (.sha256 // ""))' "$manifest" >/dev/null 2>&1 || {
		echo "Native app integrity check failed: invalid integrity list"
		return 1
	}

	while IFS=$'\t' read -r rel_path expected; do
		[ -n "$rel_path" ] || continue
		case "$rel_path" in
			/*|../*|*"/../"*|*"/.."|..)
				echo "Native app integrity check failed: unsafe file path $rel_path"
				return 1
				;;
			scripts/*|app/bin/*)
				;;
			*)
				echo "Native app integrity check failed: unsupported file path $rel_path"
				return 1
				;;
		esac

		case "$expected" in
			????????????????????????????????????????????????????????????????)
				;;
			*)
				echo "Native app integrity check failed: invalid sha256 for $rel_path"
				return 1
				;;
		esac
		case "$expected" in
			*[!0-9a-fA-F]*)
				echo "Native app integrity check failed: invalid sha256 for $rel_path"
				return 1
				;;
		esac

		file="$app_path/.pkg/$rel_path"
		[ -f "$file" ] || {
			echo "Native app integrity check failed: file missing $rel_path"
			return 1
		}

		actual=$(sha256sum "$file" | awk '{print $1}')
		if [ "$actual" != "$expected" ]; then
			echo "Native app integrity check failed: sha256 mismatch $rel_path"
			return 1
		fi
	done < <(jq -r '.integrity.files[] | ((.path // "") + "\t" + (.sha256 // ""))' "$manifest" 2>/dev/null)

	return 0
}

__native_app_stop()
{
	cd $app_path/.pkg/scripts

	[ -x "./stop.sh" ] && ./stop.sh >>$app_path/log/run.log 2>&1
	__update_run_log "$app_path" "$RUN_CODE_SUCCESS" "Application stop successfully"
	return 0
}

__native_app_start()
{
	cd $app_path/.pkg/scripts

	if ! errmsg=$(__native_app_verify_integrity 2>&1); then
		__update_run_log "$app_path" "$RUN_CODE_ERR" "$errmsg"
		return 1
	fi

	__gen_native_config
	if [ -x "./start.sh" ]; then
		 if ! ./start.sh >>$app_path/log/install.log 2>&1; then
			__update_run_log "$app_path" "$RUN_CODE_ERR" "Process failed to start. Check startup parameters or system logs for details"
			return 1
		fi
	fi
	__update_run_log "$app_path" "$RUN_CODE_SUCCESS" "Application stop successfully"
	return 0
}

__native_app_install()
{
	cd $app_path/.pkg/scripts

	__update_run_log "$app_path" "$RUN_CODE_START" "Application starting"

	if ! errmsg=$(__native_app_verify_integrity 2>&1); then
		echo "$errmsg" >>$app_path/log/install.log
		__update_run_log "$app_path" "$RUN_CODE_ERR" "$errmsg"
		return 1
	fi

	__gen_native_config

	[ -x "./PRE_INST.sh" ] && ./PRE_INST.sh >/dev/null 2>&1
	if [ -x "./start.sh" ]; then
		 if ! ./start.sh >>$app_path/log/install.log 2>&1; then
			__update_run_log "$app_path" "$RUN_CODE_ERR" "Process failed to start. Check startup parameters or system logs for details"
			return 1
		fi
	fi
	[ -x "./POST_INST.sh" ] && ./POST_INST.sh >/dev/null 2>&1
	__update_run_log "$app_path" "$RUN_CODE_SUCCESS" "Application started successfully"
	return 0
}

__native_app_uninstall()
{
	cd $app_path/.pkg/scripts

	[ -x "./PRE_UNINST.sh" ] && ./PRE_UNINST.sh >/dev/null 2>&1
	[ -x "./stop.sh" ] && ./stop.sh >>$app_path/log/install.log 2>&1
	[ -x "./POST_UNINST.sh" ] && ./POST_UNINST.sh >/dev/null 2>&1
	return 0
}

__exec_app_init()
{
	if [ "$type" = "1" ]; then
		__container_app_start
	else
		__native_app_start
	fi
}

__exec_app_install()
{
	if [ "$type" = "1" ]; then
		__container_app_install
	else
		__native_app_install
	fi
}

__exec_app_uninstall()
{
	if [ "$type" = "1" ]; then
		__container_app_uninstall
	else
		__native_app_uninstall
	fi
}

__exec_app_stop()
{
	if [ "$type" = "1" ]; then
		__container_app_stop
	else
		__native_app_stop
	fi
}

__exec_app_start()
{
	if [ "$type" = "1" ]; then
		__container_app_start
	else
		__native_app_start
	fi
}

__init_run_log()
{
	local status_path="$1"
	> $status_path/log/run.log
	echo "$RUN_CODE_START" > $status_path/log/run.status
}

__update_run_log()
{
	local status_path="$1" status_code="$2" status_message="$3"
	local timestr=$(date "+%Y-%m-%d %H:%M:%S")
	echo "$status_code" > $status_path/log/run.status
	echo "$timestr $status_message" >> $status_path/log/run.log
}

__update_process()
{
	local status_path="$1" status_code="$2" status_message="$3"
	local timestr=$(date "+%Y-%m-%d %H:%M:%S")
	echo "$status_code" > $status_path/status
	if [ "$status_message" ]; then
		echo "$timestr $status_message" >> $status_path/log/install.log
	fi
}

__update_process_bar()
{
	local status_path="$1" status_bar="$2"
	if [ "$status_bar" ]; then
		echo "$status_bar" > $status_path/log/.bar.tmp
		mv $status_path/log/.bar.tmp $status_path/log/.bar
	fi
}

__init_process()
{
	local status_path="$1"
	> $status_path/log/install.log
	
	if [ "$task_id" ]; then
		echo "$task_id" > $app_path/.task_id
	elif [ ! -e "$app_path/.task_id" ]; then
		local random_id=$(cat /proc/sys/kernel/random/uuid)
		task_id=${random_id//-*/}
		echo "$task_id" > $app_path/.task_id
	fi	
}

__init_process_pid()
{
	echo $$ > $app_path/.pid
}


__errexit_process()
{
	local status_path="$1" status_message="$2"
	echo "$PROCESS_CODE_ERR" > $status_path/status
	echo "$status_message" >> $status_path/log/install.log
}

__exec_pkg_download()
{
	if [ "$filepkg" ]; then
		if [ -e "$filepkg" ]; then
			cp -rf $filepkg/* $app_path/.pkg/
		else
			__errexit_process "$app_path" "Error: Application installation package not found."
		fi
	else
		__update_process "$app_path" "$PROCESS_CODE_DOWNLOAD_PKG" "Downloading application package"
		##download app pkg
		if ! ikluajit $IK_DIR_SCRIPT/sec/applist_control.lua app_download_direct appid="$appid" filepath="$app_path/.tmp/${name}.tar.gz" >/dev/null 2>&1; then
			__errexit_process "$app_path" "Failed to download the app. Please check your network connection."
			__update_app_queue_err
			return 1
		fi
		#pkg.tar.gz
		local file_md5value=$(md5sum $app_path/.tmp/${name}.tar.gz)
		if [ "${file_md5value// */}" != "$md5" ]; then
			__errexit_process "$app_path" "Error: MD5 checksum does not match the expected value. The file may be corrupted or incomplete."
			return 1
		fi
#		cp /etc/log/soft/${name}-${new_version}.tar.gz $app_path/.tmp/${name}.tar.gz

		__update_process "$app_path" "$PROCESS_CODE_EXTRACT_PKG" "Extracting package"
		cd $app_path
		if ! tar -zxvf .tmp/${name}.tar.gz -C .tmp/; then
			__errexit_process "$app_path" "Failed to extract the package. Please check if the package format is valid/supported"
			__update_app_queue_err
			return 1
		fi
		cp -rf $app_path/.tmp/$name/* $app_path/.pkg/
		rm -rf $app_path/.tmp/*
	fi

	if [ -d "${app_path}/.pkg/app/config" ]; then
		ln -sf ${app_path}/.pkg/app/config ${app_path}/config
		touch ${app_path}/config/environment
		if [ ! -e "${app_path}/.pkg/app/environment" ]; then
			touch ${app_path}/.pkg/app/environment
		fi
	fi

	if [ "$type" = "1" -a -d "${app_path}/.pkg/app/data" ]; then
		ln -sf ${app_path}/.pkg/app/data ${app_path}/data
	fi
	if [ "$type" = "1" -a -d "${app_path}/.pkg/app/cache" ]; then
		ln -sf ${app_path}/.pkg/app/cache ${app_path}/cache
	fi

	if [ -d "${app_path}/.pkg/ui" ]; then
		ln -s ${app_path}/.pkg/ui /usr/ikuai/www/static/appmarket/$name
	fi

	return 0
}

__set_images_info()
{
	local install_status="$1"
	local res=$(cat docker-compose.yaml |grep " image:" | awk  '{print $2}')
	for res_one in ${res}; do
		local image_info="$res_one"

		$IK_DIR_SCRIPT/docker.sh install_images name=${image_info//:*/} tag=${image_info//*:/} logo=$ico install_time=$(date +%s) status=$install_status log=$app_path/log/install.log >/dev/null 2>&1
	done
}

docker_pull_image()
{
	touch $app_path/log/.pull_running
	rm $app_path/log/.pull_success 2>/dev/null
	rm $app_path/log/.pull_failed 2>/dev/null

	if docker-compose pull --ignore-pull-failures >>$app_path/log/install.log 2>&1; then
		touch $app_path/log/.pull_success
	else
		touch $app_path/log/.pull_failed
	fi 
	rm -f $app_path/log/.pull_running
}

docker_wait_image()
{
	local bar="30"
	__update_process_bar "$app_path" "$bar"
	docker_pull_image >/dev/null 2>&1 &
	sleep 1

	while [ -f $app_path/log/.pull_running ]; do
		sleep 1
#		echo "pulling image..."
		if [ -f $app_path/log/.pull_success ]; then
#			echo "pull image success"
#			__update_process "$app_path" "$PROCESS_CODE_DOWNLOAD_IMG" "" "100"
			break
		elif [ -f $app_path/log/.pull_failed ]; then
#			echo "pull image failed"
			break
		else
			if [ "$bar" -ge "80" ]; then
				bar=$((bar+1))
			elif [ "$bar" -ge "60" ] ; then
				local random_num=$((RANDOM % 2 + 1))
				bar=$((bar+random_num))
			else
				local random_num=$((RANDOM % 4 + 1))
				bar=$((bar+random_num))
			fi
			if [ "$bar" -gt "99" ]; then
				bar="99"
			else
				__update_process_bar "$app_path" "$bar"
			fi
		fi
	done

	if [ "$bar" -lt "80" ]; then
		sleep 1
		__update_process_bar "$app_path" "85"
		sleep 1
		__update_process_bar "$app_path" "95"
		sleep 1	

	elif [ "$bar" -lt "90" ]; then
		sleep 1
		__update_process_bar "$app_path" "90"
		sleep 1
		__update_process_bar "$app_path" "96"
		sleep 1
	fi
}

__exec_img_download()
{
	if [ "$type" = "1" ]; then
		if [ "$filepkg" -a -e "$app_path/.pkg/docker_image.tar.gz" ]; then

			if [ -e "$app_path/.pkg/docker_image.tar.gz" ]; then
				size=$(ls -l $app_path/.pkg/docker_image.tar.gz  | awk '{print $5}')
			fi
			cd $app_path/.pkg
			__update_process "$app_path" "$PROCESS_CODE_DOWNLOAD_IMG" "Loading container image"
			if ! gunzip -c docker_image.tar.gz  | docker load >/tmp/load_img.$$ 2>&1; then
				local errmsg=$(cat /tmp/load_img.$$)
				__errexit_process "$app_path" "$errmsg"
				__update_app_queue_err
			fi
			rm /tmp/load_img.$$
		else
			cd $app_path/.pkg/app
			__gen_container_name
			__update_process "$app_path" "$PROCESS_CODE_DOWNLOAD_IMG" "Downloading container image"
			
			docker_wait_image

			if [ -f $app_path/log/.pull_success ]; then
				__set_images_info 0
				return 0
			else
				__errexit_process "$app_path" "Failed to download container image. Please check network connection or image name."
				__set_images_info 1
				__update_app_queue_err
				return 1
			fi
		fi
	fi
	return 0
}

__exec_config_backup()
{
	rm -rf $app_path/.backup/* >/dev/null 2>&1

	local version=$(cat $app_path/.pkg/manifest.json|jq -r .version)
	echo $version > $app_path/.backup/version
	
	if [ -d "$app_path/.pkg/app/config" ]; then
		mv $app_path/.pkg/app/config $app_path/.backup/
	fi
	if [ -d "$app_path/.pkg/app/data" ]; then
		mv $app_path/.pkg/app/data $app_path/.backup/
	fi

	#tmp
#	if [ -e "$app_path/.pkg/app/environment" ]; then
#		cp $app_path/.pkg/app/environment $app_path/.backup/
#	fi
#
#	if [ -e "$app_path/.pkg/app/.env" ]; then
#		cp $app_path/.pkg/app/.env $app_path/.backup/
#	fi


}

__exec_config_restore()
{
	if [ -d "$app_path/.backup" ]; then
		local old_version=$(cat $app_path/.backup/version)
		if [ "$(Version $old_version)" -gt "$(Version $new_version)" ]; then
			rm -rf $app_path/.backup/*
			return	
		fi
		rm $app_path/.backup/version

		if [ -d "$app_path/.backup/config" ]; then
			rm -rf $app_path/.pkg/app/config >/dev/null 2>&1
			mv $app_path/.backup/config $app_path/.pkg/app/
		fi
		if [ -d "$app_path/.backup/data" ]; then
			rm -rf $app_path/.pkg/app/data >/dev/null 2>&1
			mv $app_path/.backup/data $app_path/.pkg/app/
		fi

		#tmp
#		if [ -e "$app_path/.backup/environment" ]; then
#			mv $app_path/.backup/environment $app_path/.pkg/app/
#		fi
#
#		if [ -e "$app_path/.backup/.env" ]; then
#			mv $app_path/.backup/.env $app_path/.pkg/app/
#		fi
	fi
}

__is_port_in_use()
{
	local portlist=$($IK_DIR_SCRIPT/utils/analyze_compose_ports.sh -f ./docker-compose.yaml -e ./.env 2>/dev/null)
	if [ "$portlist" ]; then
		local $portlist
		#tcplist= udplist=
	fi
	if ! errmsg=$($IK_DIR_SCRIPT/utils/check_services_port.sh check_services_port tcplist="$tcplist" udplist="$udplist" exclude=$exclude 2>/dev/null); then
		echo "$errmsg"
		return 1
	fi
	return 0
}

__app_update()
{
	__init_process_pid

	__exec_config_backup
	if ! __exec_pkg_download; then
		return 1
	fi

	if ! __exec_img_download; then
		return 1
	fi

	local res=$(sql_config_get_list $APPTMPDB "select * from applist where appid=$appid")
	[ "$res" ] || return 0

	local $res

	__exec_config_restore

	local timestamp=$(date +%s)
	local current_version="$new_version"
	local sql_param=" timestamp:int display_name:str location:str ico:str type:int size:int "
	local sql_param+=" restart:int current_version:str maintainer:str maintainer_url:str distributor:str distributor_url:str"
	local sql_param+=" origin:int update_time:int install_path:str desc:str desc_url:str readme:str changelog:str"
	local sql_param+= "category:int sub_category:int"
	if SqlMsg=$(sql_config_update $IK_DB_APPMARKET applist "name='$name'" $sql_param); then
		__apps_to_cache
		[ "$enabled" = "yes" ] && {
			__init_run_log "$app_path"
			__exec_app_install >/dev/null 2>/dev/null
		}
		fsyslog_custom "$(Autoiecho appmarket app_update $display_name)"
		__update_process "$app_path" "$PROCESS_CODE_SUCCESS" "Installation completed"
		__finish_app_queue
		__exec_app_queue
		return 0
	else
		__errexit_process "$app_path" "Installation failed, error writing to the database, $SqlMsg"
		__update_app_queue_err
		return 1
	fi
}

__app_install()
{
	__init_process_pid
	if ! __exec_pkg_download; then
		return 1
	fi

	if ! __exec_img_download; then
		return 1
	fi

	__exec_config_restore
	if [ "$origin" = "3" ]; then
		if [ -e "$app_path/.pkg/ui/ico/app.png" ]; then
			ico="/static/appmarket/$name/ico/app.png"
		fi
		if [ -e "$app_path/.pkg/changelog" ]; then
			changelog=$(cat $app_path/.pkg/changelog | base64 | tr -d '\n')
		fi

		if [ -e "$app_path/.pkg/readme" ]; then
			readme=$(cat $app_path/.pkg/readme |base64 | tr -d '\n') 
		fi
		for file_one in $(ls $app_path/.pkg/ui/images); do
			desc_url+="${desc_url:+,}/static/appmarket/$name/images/$file_one"
		done
		
		if [  "$ARCH" = "x86" -a -z "$ENTERPRISE" ]; then
			local res=$(sqlite3 $IK_DB_APPMARKET "select id from applist where origin=3")
			if [ "$res" -a -d "$app_path" ]; then
				rm -rf $app_path
				return 0
			fi
		fi
	fi

	local timestamp=$(date +%s)
	local current_version="$new_version"
	local location=""
	local sql_param=" enabled:str name:str appid:int timestamp:int display_name:str location:str ico:str type:int size:int"
	local sql_param+=" restart:int current_version:str maintainer:str maintainer_url:str distributor:str distributor_url:str"
	local sql_param+=" origin:int update_time:int install_path:str desc:str desc_url:str readme:str changelog:str"
	local sql_param+=" category:int sub_category:int"
	if SqlMsg=$(sql_config_insert $IK_DB_APPMARKET applist $sql_param); then
		__apps_to_cache
		[ "$enabled" = "yes" ] && {
			__init_run_log "$app_path"
			__exec_app_install >/dev/null 2>/dev/null
		}
		fsyslog_custom "$(Autoiecho appmarket app_install $display_name)"
		__update_process "$app_path" "$PROCESS_CODE_SUCCESS" "Installation completed"
		__finish_app_queue
		__exec_app_queue
		ikluajit $IK_DIR_SCRIPT/sec/applist_control.lua app_install id=$appid >/dev/null 2>&1 &
		$IK_DIR_SCRIPT/msgcenter.sh add type=3 event="app_install_success" msg_param="$display_name" >/dev/null 2>&1 &

		if [ "$origin" = "3" -a "$session_base_path" -a -e "$session_base_path" ]; then
			rm -rf $session_base_path 2>/dev/null
		fi
		if [ "$origin" = "3" -a -e "$app_path/.pkg/app/docker-compose.yaml" ]; then
			local image_info=$(awk  '/image:/{print $2;exit}' $app_path/.pkg/app/docker-compose.yaml)
			local image_size=$(docker image inspect $image_info --format='{{.Size}}')
			if [ "$image_size" ]; then
				sqlite3 $IK_DB_APPMARKET "update applist set size=$image_size where appid=$appid"
			fi
		fi
		return 0
	else
		__errexit_process "$app_path" "Installation failed, error writing to the database, $SqlMsg"
		__update_app_queue_err
		return 1
	fi
}

#backup=1
__app_uninstall()
{
	__init_run_log "$app_path"
	__exec_app_uninstall

	if [ "$name" -a -d "$app_path" ]; then
		if [ "$backup" = "1" ]; then
			__exec_config_backup
			rm -rf $app_path/.pkg
			rm -rf $app_path/.tmp
			rm -rf $app_path/config
			rm -rf $app_path/data
			rm -rf $app_path/cache
			rm -rf $app_path/status
			rm -rf $app_path/log
		else
			rm -rf /etc/mnt/ikuai/appmarket/$name
			rm -rf $app_path
		fi
	fi
	if [ "$name" ]; then
		rm $APPMARKET_DIR/$name
		rm /usr/ikuai/www/appmarket/$name
	fi
	fsyslog_custom "$(Autoiecho appmarket app_uninstall $display_name)"
}

__pre_app_install()
{
	mkdir -p $app_path
	mkdir -p $app_path/.pkg
	mkdir -p $app_path/.pkg/app/config
	mkdir -p $app_path/.pkg/app/data
	mkdir -p $app_path/.pkg/app/cache
	mkdir -p $app_path/log
	mkdir -p $app_path/.backup
	mkdir -p $app_path/.tmp

	if [ ! -e "$APPMARKET_DIR/$name" ]; then
		ln -s $app_path $APPMARKET_DIR/$name
	fi

	__init_process "$app_path"
	local queue_status=$(__get_queue_status)
	if [ "$queue_status" = "1" ]; then
		__update_process "$app_path" "$PROCESS_CODE_IN_QUEUE" "In download queue"
#		if $IK_DIR_SCRIPT/task_queue.sh check_is_limit module_name="appmarket" limit="5"; then
		if $IK_DIR_SCRIPT/task_queue.sh check_queue_limit; then
			return 1
		fi
	elif [ "$queue_status" = "0" ]; then
		__add_app_queue
		__update_process "$app_path" "$PROCESS_CODE_IN_QUEUE" "In download queue"
#		if $IK_DIR_SCRIPT/task_queue.sh check_is_limit module_name="appmarket" limit="5"; then
		if $IK_DIR_SCRIPT/task_queue.sh check_queue_limit; then
			return 1
		fi
	fi

	__update_app_queue_run

	__update_process "$app_path" "$PROCESS_CODE_INSTALL_START" "Installation started"

	return 0
}

#install_file: appid= enabled= type= path= display_name= queue=0|1 filename=
#docker: appid= enabled=
#native: appid= enabled= path=
install() {
	if [ "$queue" != "1" ]; then
		if ! errmsg=$(__check_param_install); then
			outputErrorLog "errcode_param_error" "$errmsg"
			return 1
		fi
	fi
	
	if [ -z "$filepkg" ]; then
		local config=$(sql_config_get_list $APPTMPDB "select id,name,display_name,appid,timestamp,location,ico,type,size,restart,new_version,maintainer,maintainer_url,distributor,distributor_url,origin,update_time,stars,download,desc,desc_url,category,sub_category,md5,readme,changelog from applist where appid=$appid")
		if [ -z "$config" ]; then
			return 1	
		fi
		local $config
	fi

	if ! __check_memory_size; then
		outputErrorLog "errcode_out_of_memory"	
		return 1
	fi


	if [ "$type" = "1" ]; then
		local workdisk=$(sqlite3 $IK_DB_DOCKER "select workdisk from global")

		if ! __check_disk_size $workdisk; then
			outputErrorLog "errcode_disk_space_full"
			return 1
		fi

		if [ ! -d "${ROOT_PATH}$workdisk" ]; then
			outputErrorLog "errcode_dir_not_found"
			return 1
		fi

		local install_path=$workdisk
		local app_path="${ROOT_PATH}${install_path}/apps/$name"
	else
		if [ "$path" = "$SYSTEM_DEFAULT" -o "$path" = "" ]; then
			local workdisk="$SYSTEM_DEFAULT"

			if ! __check_system_disk_size; then
				outputErrorLog "errcode_disk_space_full"
				return 1
			fi
			local install_path=$workdisk
			local app_path="${install_path}/apps/$name"
		else
			local workdisk="${path//\/*/}"
			if ! __check_disk_size $workdisk; then
				outputErrorLog "errcode_disk_space_full"
				return 1
			fi

			if [ ! -d "${ROOT_PATH}$workdisk" ]; then
				outputErrorLog "errcode_dir_not_found"
				return 1
			fi

			local install_path=$workdisk
			local app_path="${ROOT_PATH}${install_path}/apps/$name"
		fi
	fi

	if ! __pre_app_install ; then
		return 0
	fi

	__app_install >/dev/null 2>&1 &

	return 0
}

#filename=
delete_file()
{

	if [ -z "$IKREST_SESSION" ]; then
		echo "set IKREST_SESSION"
		return 0
	fi

	local res=$($IK_DIR_SCRIPT/utils/file_find.lua "/")
	if [ "$res" = "{}" ]; then
		return 0
	fi

	local workdisk=$(sqlite3 $IK_DB_DOCKER "select workdisk from global")

	if [ ! -d "${ROOT_PATH}$workdisk" ]; then
		return 0
	fi

	local install_path=$workdisk
	local pkg_path="${ROOT_PATH}${install_path}/.pkg"
	if [ "$filename" -a -e "${pkg_path}/$filename" ]; then
		rm -rf ${pkg_path}/$filename >/dev/null 2>&1
	fi
	if [ "$IKREST_SESSION" -a -e "$pkg_path/$IKREST_SESSION" ]; then
		rm -rf $pkg_path/$IKREST_SESSION >/dev/null 2>&1
	fi

	return 0
}

#docker: enabled=
#docker: enabled= filename= mode=0|1|2
install_file()
{

	if [ -z "$IKREST_SESSION" ]; then
		echo "set IKREST_SESSION"
		return 1
	fi

	local res=$($IK_DIR_SCRIPT/utils/file_find.lua "/")
	if [ "$res" = "{}" ]; then
		support_disk=0
		outputErrorLog "errcode_disk_error"
		return 1
	fi

	local workdisk=$(sqlite3 $IK_DB_DOCKER "select workdisk from global")

	if ! __check_disk_size $workdisk; then
		outputErrorLog "errcode_disk_space_full"	
		return 1
	fi

	if [ ! -d "${ROOT_PATH}$workdisk" ]; then
		outputErrorLog "errcode_dir_not_found"
		return 1
	fi

	local mode=${mode:-0}
	local install_path=$workdisk
	local pkg_path="${ROOT_PATH}${install_path}/.pkg"

	if [ -e "${pkg_path}/$filename" ]; then
		local size=$(ls -l ${pkg_path}/$filename  | awk '{print $5}')
		rm ${pkg_path}/$filename >/dev/null 2>&1
	fi

	local name=$(ls $pkg_path/$IKREST_SESSION/)
	if [ "$IKREST_SESSION" -a -e "$pkg_path/$IKREST_SESSION" ]; then
		local session_base_path="$pkg_path/$IKREST_SESSION"
	fi
	local filepkg="$pkg_path/$IKREST_SESSION/$name"
	
	local filepath="$filepkg/manifest.json"
	if [ "$name" -a -e "$filepath" ]; then
		json_decode_file manifest $filepath

		local update_time=$(date +%s) location= ico= restart=0
		local name=${manifest_name} display_name=${manifest_display_name// /%20} type=${manifest_type}
		local new_version=${manifest_version} maintainer=${manifest_maintainer// /%20} maintainer_url=${manifest_maintainer_url}
		local distributor=${manifest_distributor// /%20} distributor_url=${manifest_distributor_url} 
		local desc=$(echo -n "${manifest_description}"|base64 | tr -d '\n') 
		local readme=""
		if [ -e "$filepath/readme" ]; then
			readme=$(cat $filepath/readme |base64 | tr -d '\n') 
		fi
		local origin=3 install_path= category=7 sub_category=0 type=1
#		local origin=3 install_path= category=7 sub_category=0
		if [ "$type" = "1" -a "$install_path" ]; then
			path="$install_path"
		fi

		local appid=$(sqlite3 $APPTMPDB "select appid from applist where name='$name'")
		if [ -z "$appid" ]; then
			local appid=$(get_next_appid)
		fi
		local queue=1
		if [ "$name" -a "$display_name" -a "$maintainer" -a "$distributor" -a "$type" -a "$new_version" -a "$desc" ]; then

			local old_appid=$(sqlite3 $IK_DB_APPMARKET "select appid from applist where name='$name'")
			if [ "$mode" = "0" ]; then
				#install
				if ! errmsg=$(install); then
					outputErrorLog "errcode_param_error" "$errmsg"
					return 1
				fi
			elif [ "$mode" = "1" ]; then
				$IK_DIR_SCRIPT/appmarket.sh uninstall appid=$old_appid backup=1 >/dev/null 2>&1
				if ! errmsg=$(install); then
					outputErrorLog "errcode_param_error" "$errmsg"
					return 1
				fi
			else
				#uninstall--install
				$IK_DIR_SCRIPT/appmarket.sh uninstall appid=$old_appid backup=0 >/dev/null 2>&1
				if ! errmsg=$(install); then
					outputErrorLog "errcode_param_error" "$errmsg"
					return 1
				fi

			fi
		else
			outputErrorLog "errcode_param_error" "manifest.json"
			return 1
		fi
	else
		outputErrorLog "errcode_dir_not_found"
		return 1
	fi
	return 0
}

retry()
{
	local queue=1
	if ! errmsg=$(install); then
		echo "$errmsg"
		return 1
	fi
	return 0
}

#appid= backup= reason= name=
uninstall() {

	local sqlparam="where appid in ($appid)"

	local res=$(sqlite3 $IK_DB_APPMARKET "select name from applist $sqlparam")
	if [ -z "$res" -a "$name" ]; then
		local appid=$(sqlite3 $IK_DB_APPMARKET "select appid from applist where name='$name'")
		if [ "$appid" ]; then
			local sqlparam="where appid in ($appid)"
		fi
	fi

	sql_config_get_list $IK_DB_APPMARKET "select name,display_name,type,appid,install_path from applist $sqlparam; delete from applist $sqlparam" \
	|while read config ;do
		if [ -n "$config" ];then
			local $config
			[ "$name" ] || continue

			if [ "$type" = "1" ]; then
				local app_path="${ROOT_PATH}${install_path}/apps/$name"
			else
				if [ "$install_path" = "$SYSTEM_DEFAULT" -o "$install_path" = "" ]; then
					local app_path="${SYSTEM_DEFAULT}/apps/$name"
				else
					local app_path="${ROOT_PATH}${install_path}/apps/$name"
				fi
			fi

			__app_uninstall >/dev/null 2>/dev/null
			ikluajit $IK_DIR_SCRIPT/sec/applist_control.lua app_uninstall id=$appid reason=$reason backups=$backup >/dev/null 2>&1 &
		fi
	done
	__apps_to_cache
	return 0
}

#appid=
update_app()
{
	if [ "$appid" ]; then
		local sqlparam="where appid in ($appid)"
	elif [ "$name" ]; then
		local names=""
		for name_one in ${name//,/ }; do
			names+="${names:+,}'$name_one'"
		done
		local sqlparam="where name in ($names)"
	fi

	if ! __check_memory_size; then
		outputErrorLog "errcode_out_of_memory"	
		return 1
	fi
	
	sql_config_get_list $IK_DB_APPMARKET "select * from applist $sqlparam;" \
	|while read config ;do
		local $config

		local res=$(sql_config_get_list $APPTMPDB "select new_version,md5 from applist where appid=$appid")
		[ -z "$res" ] && continue
		local $res
		if [ "$(Version $current_version)" -ge "$(Version $new_version)" ]; then
			continue	
		fi
		if [ "$type" = "1" ]; then
			local app_path="${ROOT_PATH}${install_path}/apps/$name"
		else
			if [ "$install_path" = "$SYSTEM_DEFAULT" -o "$install_path" = "" ]; then
				local app_path="${SYSTEM_DEFAULT}/apps/$name"
			else
				local app_path="${ROOT_PATH}${install_path}/apps/$name"
			fi
		fi
		if __pre_app_install; then
			__app_update >/dev/null 2>/dev/null &
		fi
	done
	return 0
}

#appid= is_liked=0|1
update_stars()
{
	local name=$(sqlite3 $IK_DB_APPMARKET "select name from applist where appid=$appid")
	if [ "$name" -a -e "/var/appmarket/$name" ]; then
		echo $is_liked > /var/appmarket/$name/.is_liked		
		if [ "$is_liked" = "1" ]; then
			ikluajit $IK_DIR_SCRIPT/sec/applist_control.lua app_stars id=$appid action="add" >/dev/null 2>&1
		else
			ikluajit $IK_DIR_SCRIPT/sec/applist_control.lua app_stars id=$appid action="remove" >/dev/null 2>&1
		fi
		(sleep 1; sync_apps >/dev/null 2>&1) &
	fi
	return 0
}

update_config_tmp()
{
	local default_dir="/var/appmarket"
	local sqlparam="where appid in ($appid)"
	local res=$(sql_config_get_list $IK_DB_APPMARKET "select name,type from applist $sqlparam;")
	[ "$res" ] || return 1
	local $res
	
	if [ "$name" -a ! -e "${default_dir}/$name" ]; then
		return 0
	fi

	local filename="/tmp/env.config.$$"
	if [ "$config" ]; then
		> $filename
		local res=$(echo $config|base64 -d)
		local env_info=$(echo $res | jq -r .environment[])
		echo $res | jq -r .environment[] | while read config; do
			echo $config >> $filename
		done		
		mv $filename ${default_dir}/${name}/.pkg/app/environment

		> $filename
		local default_env=$(echo $res | jq -r .default_env[])
		echo $res | jq -r .default_env[] | while read config; do
			echo $config >> $filename
		done		
		mv $filename ${default_dir}/${name}/.pkg/app/.env
	fi
	echo "CPUS_LIMIT=${cpus_limit:-0}" >> ${default_dir}/${name}/.pkg/app/.env
	echo "MEMORY_LIMIT=${memory_limit:-0}" >> ${default_dir}/${name}/.pkg/app/.env
	echo "RESTART=${restart:-always}" >> ${default_dir}/${name}/.pkg/app/.env
	echo "HOST_IP=${host_ip:-0.0.0.0}" >> ${default_dir}/${name}/.pkg/app/.env

	fsyslog_custom "$(Autoiecho appmarket app_config $display_name)"

	return 0
}

#appid= name= is_installed=0
update_config()
{
	local default_dir="/etc/mnt/ikuai/appmarket"
#	local sqlparam="where appid in ($appid)"
#	local res=$(sql_config_get_list $IK_DB_APPMARKET "select name,type from applist $sqlparam;")
#	[ "$res" ] || return 1
#	local $res
	
	[ "$name" ] || return 1
	
	mkdir -p ${default_dir}/$name	

	local filename1="/tmp/env1.config.$$"
	local filename2="/tmp/env2.config.$$"
	if [ "$config" ]; then
		> $filename1
		local res=$(echo $config|base64 -d)
		echo $res | jq -r .environment[] 2>/dev/null | while read config; do
			echo $config >> $filename1
		done		

		> $filename2
		echo $res | jq -r .default_env[] 2>/dev/null | while read config; do
			echo $config >> $filename2
		done		

		local tcplist=""
		local udplist=""
		local tmpfile=$(echo $res | jq -r .default_env[])
		while read config; do
			if [ "${config:0:12}" = "APP_PORT_UDP" ]; then
				local app_port=${config//*=/}
				udplist+="${udplist:+,}$app_port"
			
			elif [ "${config:0:8}" = "APP_PORT" ]; then
				local app_port=${config//*=/}
				tcplist+="${tcplist:+,}$app_port"
			elif [ "${config:0:7}" = "HOST_IP" ]; then
				local host_ip=${config//*=/}
				if ! check_is_ip "$host_ip"; then
					host_ip=""
				fi
			fi
		done <<EOF
		$tmpfile
EOF

		local nonce_str=$(echo "${name}"|md5sum)
		local NAME_NONCE=${nonce_str:0:6}
		local exclude="${name}-${NAME_NONCE}"
		if ! errmsg=$($IK_DIR_SCRIPT/utils/check_services_port.sh check_services_port tcplist="$tcplist" udplist="$udplist" exclude=$exclude 2>/dev/null); then
			outputErrorLog "errcode_port_conflict" "$errmsg"
			return 1
		fi

		mv $filename1 ${default_dir}/${name}/environment
		mv $filename2 ${default_dir}/${name}/default_env
	fi
	echo "CPUS_LIMIT=${cpus_limit:-0}" >> ${default_dir}/${name}/default_env
	echo "MEMORY_LIMIT=${memory_limit:-0}" >> ${default_dir}/${name}/default_env
	echo "RESTART=${restart:-always}" >> ${default_dir}/${name}/default_env

	local app_type=$(sqlite3 $IK_DB_APPMARKET "select type from applist where appid=$appid")
	if [ -z "$app_type" ]; then
		app_type=$(sqlite3 $APPTMPDB "select type from applist where appid=$appid")
	fi
	local app_type=${app_type:-1}

	if [ "$app_type" = "1" ]; then
		if [ "$expose_port" = "1" ]; then
			echo "HOST_IP=0.0.0.0" >> ${default_dir}/${name}/default_env
		else
			if [ "$host_ip" -a "$host_ip" != "0.0.0.0" ]; then
				echo "HOST_IP=${host_ip}" >> ${default_dir}/${name}/default_env
			else
				local doc_ipaddr=$(interface_get_ipaddr doc_app_default)
				if [ "$doc_ipaddr" ]; then
					echo "HOST_IP=$doc_ipaddr" >> ${default_dir}/${name}/default_env
				else
					echo "HOST_IP=127.0.0.1" >> ${default_dir}/${name}/default_env
				fi
			fi
		fi
	else
		if [ "$expose_port" = "1" ]; then
			echo "HOST_IP=0.0.0.0" >> ${default_dir}/${name}/default_env
		else
			if [ "$host_ip" -a "$host_ip" != "0.0.0.0" ]; then
				echo "HOST_IP=${host_ip}" >> ${default_dir}/${name}/default_env
			else
				local doc_ipaddr=$(interface_get_ipaddr lan1)
				if [ "$doc_ipaddr" ]; then
					echo "HOST_IP=$doc_ipaddr" >> ${default_dir}/${name}/default_env
				else
					echo "HOST_IP=127.0.0.1" >> ${default_dir}/${name}/default_env
				fi
			fi
		fi
	fi

#	cp ${default_dir}/${name}/environment /var/appmarket/$name/.pkg/app/
#	cp ${default_dir}/${name}/default_env /var/appmarket/$name/.pkg/app/.env

	local display_name=$(sqlite3 $IK_DB_APPMARKET "select display_name from applist where appid=$appid")
	if [ "$display_name" ]; then
		fsyslog_custom "$(Autoiecho appmarket app_config $display_name)"
	fi

	return 0
}


#appid=
down() {
	local sqlparam="where appid in ($appid)"

	sql_config_get_list $IK_DB_APPMARKET "select * from applist $sqlparam; update applist set enabled='no' $sqlparam" \
	|while read config ;do
		local $config
		if [ "$type" = "1" ]; then
			local app_path="${ROOT_PATH}${install_path}/apps/$name"
		else
			if [ "$install_path" = "$SYSTEM_DEFAULT" -o "$install_path" = "" ]; then
				local app_path="${SYSTEM_DEFAULT}/apps/$name"
			else
				local app_path="${ROOT_PATH}${install_path}/apps/$name"
			fi
		fi
		__init_run_log "$app_path"
		__exec_app_stop >/dev/null 2>/dev/null
	done
	__apps_to_cache
	return 0
}

#appid=
up() {
	if ! __check_memory_size; then
		outputErrorLog "errcode_out_of_memory"	
		return 1
	fi
	local sqlparam="where appid in ($appid)"

	sql_config_get_list $IK_DB_APPMARKET "select * from applist $sqlparam; update applist set enabled='yes' $sqlparam" \
	|while read config ;do
		local $config
		if [ "$type" = "1" ]; then
			local app_path="${ROOT_PATH}${install_path}/apps/$name"
		else
			if [ "$install_path" = "$SYSTEM_DEFAULT" -o "$install_path" = "" ]; then
				local app_path="${SYSTEM_DEFAULT}/apps/$name"
			else
				local app_path="${ROOT_PATH}${install_path}/apps/$name"
			fi
		fi
		__init_run_log "$app_path"
		__exec_app_start >/dev/null 2>/dev/null
	done
	__apps_to_cache
	return 0
}

#appid=
app_cache_clean()
{
	local sqlparam="where appid in ($appid)"

	sql_config_get_list $IK_DB_APPMARKET "select * from applist $sqlparam; " \
	|while read config ;do
		local $config

		if [ "$type" = "1" ]; then
			local app_path="${ROOT_PATH}${install_path}/apps/$name"
		else
			if [ "$install_path" = "$SYSTEM_DEFAULT" -o "$install_path" = "" ]; then
				local app_path="${SYSTEM_DEFAULT}/apps/$name"
			else
				local app_path="${ROOT_PATH}${install_path}/apps/$name"
			fi
		fi
		if [ -d "$app_path/.pkg/app/cache" ]; then
			rm -rf $app_path/.pkg/app/cache/*
		fi
	done
	return 0
}

#appid=
add_ignore_list()
{
	local sqlparam="where appid in ($appid)"
	sqlite3 $IK_DB_APPMARKET "update applist set ignore_update=1 $sqlparam"
	return 0
}

#appid=
del_ignore_list()
{
	local sqlparam="where appid in ($appid)"
	sqlite3 $IK_DB_APPMARKET "update applist set ignore_update=0 $sqlparam"
	return 0
}

__apps_to_cache()
{
	$LOCKUP_CACHE
	sql_config_get_list $IK_DB_APPMARKET "select enabled,name,current_version,ignore_update,install_path from applist" > $IK_DIR_TMP/appmarket/config.$$
	mv $IK_DIR_TMP/appmarket/config.$$ $IK_DIR_TMP/appmarket/config
	$UNLOCK_CACHE
}

app_network_init()
{
	for value in {20..40}; do
		local addr="172.18.$value.0/24"
		local gateway="172.18.$value.1"
		if $IK_DIR_SCRIPT/utils/check_addrpool.lua $addr; then
			ikdocker network_add name="doc_app_default" subnet="$addr" gateway="$gateway" comment="App"
			break
		fi
	done
}

sync_apps()
{
	__apps_list_get >/dev/null 2>&1 &
	return 0
}

get_self_taskid()
{
	local task_id=$(cat $app_path/.task_id)
	echo "${task_id}"
}

#appid= name= enabled= path=
__add_app_queue()
{
	local timestamp="$(date +%s)"

	local module_name="appmarket" timestamp=$timestamp task_name="$name" task_desc="$display_name"
	local task_path="$app_path"
	local task_params="enabled=$enabled path=$path appid=$appid"
	local task_params=$(echo -n "$task_params"|base64 | tr -d '\n')
	local task_id=$(get_self_taskid)

	$IK_DIR_SCRIPT/task_queue.sh add ico=$ico task_key=$appid task_id=$task_id module_name="appmarket" timestamp=$timestamp task_name="$name" task_desc="$display_name" task_path="$app_path" task_params="$task_params" >/dev/null 2>&1 
}

__finish_app_queue()
{
	local task_id=$(get_self_taskid)
	$IK_DIR_SCRIPT/task_queue.sh update_finish_status task_id=$task_id >/dev/null 2>&1
#	$IK_DIR_SCRIPT/task_queue.sh del task_id=$task_id >/dev/null 2>&1 
#	$IK_DIR_SCRIPT/task_queue.sh record_add task_id=$task_id module_name="appmarket" task_name="$name" task_desc="$display_name" >/dev/null 2>&1  
}

__exec_app_queue()
{
	rm $app_path/.task_id
	rm $app_path/.pid
	$IK_DIR_SCRIPT/task_queue.sh next >/dev/null 2>&1 &
}

__get_queue_status()
{
	local task_id=$(get_self_taskid)
	local res=$($IK_DIR_SCRIPT/task_queue.sh check_queue_status task_id=$task_id 2>/dev/null)	
	echo "$res"
}

__update_app_queue_err()
{
	local task_id=$(get_self_taskid)
	$IK_DIR_SCRIPT/task_queue.sh update_errexit_status task_id=$task_id >/dev/null 2>&1 
	$IK_DIR_SCRIPT/msgcenter.sh add type=3 event="app_install_failed" msg_param="$display_name"  >/dev/null 2>&1 
	__exec_app_queue
}

__update_app_queue_run()
{
	local task_id=$(get_self_taskid)
	$IK_DIR_SCRIPT/task_queue.sh update_run_status task_id=$task_id >/dev/null 2>&1 
}

__apps_list_get()
{
	if $LOCKUP_NB; then
		touch ${IK_DIR_TMP}/appmarket/.load_app
		ikluajit $IK_DIR_SCRIPT/sec/applist_control.lua app_get >/dev/null 2>&1
		rm $IK_DIR_TMP/appmarket/.load_app
		$UNLOCK
	fi
}

__implant_code()
{
cat -<<EOF
	local sqlite3 = require "lsqlite3"	
	local cjson = require "cjson"
	local workdisk="$workdisk"

	local apps_info = {}
	local tmpdb = sqlite3.open("/tmp/iktmp/appmarket/apptmp.db")
	if tmpdb then
		tmpdb:busy_timeout(10000)

		local sql = "select * from applist"
		for row in tmpdb:nrows(sql) do
			apps_info[row.name] = row
		end
		tmpdb:close()
	end

	local container_status = {}

	local dockerd_status = 0
	local fp= io.open("/usr/sbin/ikdocker", "r")
	if fp then
		dockerd_status = 1
		fp:close()
	end
	if dockerd_status == 1 then
		local cmd = string.format("ikdocker container_get workdir=%s",workdisk)
		local fp = io.popen(cmd)
		if fp then
			local res = fp:read("*a")

			local success, docker_info = pcall(cjson.decode, res)
			if success then
				for k,v in pairs(docker_info) do
					if v.state == "running" then
						container_status[v.name] = 1
					end
				end
			end
			fp:close()
		end
	end

        ikdb:create_function('is_installed',1,
                function (ctx, name)
			local res = 1
                        ctx:result_int(res) 
                end
        )

        ikdb:create_function('has_newversion',2,
                function (ctx, name, current_version)
			local res = 0
			local row = apps_info[name]
			if row and  row.new_version then
				local a,b,c = current_version:match("(%d+)%.(%d+)%.(%d+)")
				local tmp_current_version = tonumber(string.format("%d%04d%04d", a,b,c))
				
				local new_version = row.new_version
				local a,b,c = new_version:match("(%d+)%.(%d+)%.(%d+)")
				local tmp_new_version = tonumber(string.format("%d%04d%04d", a,b,c))

				if tmp_new_version > tmp_current_version then
					res = 1
				end
			end
                        ctx:result_int(res) 
                end
        )

        ikdb:create_function('new_version',1,
                function (ctx, name)
			local res = ""
			local row = apps_info[name]
			if row and  row.new_version then
				res = row.new_version
			end
                        ctx:result_text(res) 
                end
        )
        ikdb:create_function('newversion_update_time',1,
                function (ctx, name)
			local res = 0
			local row = apps_info[name]
			
			if row then
				res = row.update_time or 0
			end

                        ctx:result_int(res or 0) 
                end
        )

        ikdb:create_function('current_download',1,
                function (ctx, name)
			local res = 0
			local row = apps_info[name]
			
			if row and row.download then
				res = row.download
			end
                        ctx:result_int(res or 0) 
                end
        )
        ikdb:create_function('current_stars',1,
                function (ctx, name)
			local res = 0
			local row = apps_info[name]
			if row and row.stars then
				res = row.stars
			end
                        ctx:result_int(res or 0) 
                end
        )
        ikdb:create_function('status',1,
                function (ctx, name)
			local res = 0
			local path = string.format("/var/appmarket/%s/status", name)
			local f = io.open(path, "r")
			if f then
				res = f:read("*a")
				f:close()
			end
		
                        ctx:result_int(res or 0) 
                end
        )
        ikdb:create_function('is_enabled',2,
                function (ctx, enabled, name)
			local res = 0
			local run_status=0
			local path = string.format("/var/appmarket/%s/log/run.status", name)
			local f = io.open(path, "r")
			if f then
				run_status = f:read("*a")
				f:close()
			end
			local run_status = tonumber(run_status) or 0

			if enabled == "yes" and run_status == 0 then
				res = 1
			end

			local tmp_name
			local path = string.format("/var/appmarket/%s/.pkg/container_name", name)
			local f = io.open(path, "r")
			if f then
				tmp_name = f:read("*l")
				f:close()
			end

			local up_status = 0
			if tmp_name then
				if container_status[tmp_name] == 1 then
					up_status = 1
				end

				if res == 1 and up_status == 1 then
					res = 1
				else
					res = 0
				end
			else
				if enabled == "yes" then
					res = 1
				end
			end

		
                        ctx:result_int(res) 
                end
        )
        ikdb:create_function('run_status',1,
                function (ctx, name)
			local res = 0
			local path = string.format("/var/appmarket/%s/log/run.status", name)
			local f = io.open(path, "r")
			if f then
				res = f:read("*a")
				res = tonumber(res) or 0
				f:close()
			end

                        ctx:result_int(res or 0) 
                end
        )

        ikdb:create_function('is_liked',1,
                function (ctx, name)
			local res = 0
			local is_liked=0
			local path = string.format("/var/appmarket/%s/.is_liked", name)
			local f = io.open(path, "r")
			if f then
				is_liked = f:read("*a")
				f:close()
			end
			local is_liked = tonumber(is_liked) or 0

                        ctx:result_int(is_liked) 
                end
        )

        ikdb:create_function('desc_info',2,
                function (ctx, name, desc)
			local res = desc
			local row = apps_info[name]
			if row and  row.desc then
				res = row.desc
			end
                        ctx:result_text(res)
                end
        )

        ikdb:create_function('desc_url_info',2,
                function (ctx, name, desc_url)
			local res = desc_url
			local row = apps_info[name]
			if row and  row.desc_url then
				res = row.desc_url
			end
                        ctx:result_text(res)
                end
        )

        ikdb:create_function('readme_info',2,
                function (ctx, name, readme)
			local res = readme
			local row = apps_info[name]
			if row and  row.readme then
				res = row.readme
			end
                        ctx:result_text(res)
                end
        )

        ikdb:create_function('changelog_info',2,
                function (ctx, name, changelog)
			local res = changelog
			local row = apps_info[name]
			if row and  row.changelog then
				res = row.changelog
			end
                        ctx:result_text(res)
                end
        )

EOF
}

__apps_implant_code()
{
cat -<<EOF
	local cjson = require "cjson"
	local workdisk="$workdisk"

	local container_status = {}

	local dockerd_status = 0
	local fp= io.open("/usr/sbin/ikdocker", "r")
	if fp then
		dockerd_status = 1
		fp:close()
	end
	if dockerd_status == 1 then
		local cmd = string.format("ikdocker container_get workdir=%s",workdisk)
		local fp = io.popen(cmd)
		if fp then
			local res = fp:read("*a")

			local success, docker_info = pcall(cjson.decode, res)
			if success then
				for k,v in pairs(docker_info) do
					if v.state == "running" then
						container_status[v.name] = 1
					end
				end
			end
			fp:close()
		end
	end
	local CACHE_APP = {}
        local f = io.open("/tmp/iktmp/appmarket/config")
        if f then
                for line in f:lines() do
                        local enabled,name,current_version,ignore_update,install_path = line:match("^enabled=([^ ]+) +name=([^ ]+) +current_version=([^ ]+) +ignore_update=([^ ]+) +install_path=([^ ]*)")
                        if enabled and name and current_version and ignore_update and install_path then
                                CACHE_APP[name] = {enabled=enabled,current_version=current_version,ignore_update=ignore_update,install_path=install_path}
                        end
                end
                f:close()
        end

        ikdb:create_function('ignore_update',1,
                function (ctx, name)
			local ignore_update = 0
			if CACHE_APP[name] and CACHE_APP[name].ignore_update then
				ignore_update = CACHE_APP[name].ignore_update or 0
			end
                        ctx:result_int(ignore_update) 
                end
        )

        ikdb:create_function('location',1,
                function (ctx, name)
			local res = ""
                        ctx:result_text(res) 
                end
        )

        ikdb:create_function('install_path',1,
                function (ctx, name)
			local install_path = ""
			if CACHE_APP[name] then
				install_path = CACHE_APP[name].install_path or ""
			end
                        ctx:result_text(install_path) 
                end
        )

        ikdb:create_function('is_installed',1,
                function (ctx, name)
			local res = 0
			if CACHE_APP[name] then
				res = 1
			end
                        ctx:result_int(res) 
                end
        )
        ikdb:create_function('is_enabled',1,
                function (ctx, name)
			local res = 0
			local run_status=0
			local path = string.format("/var/appmarket/%s/log/run.status", name)
			local f = io.open(path, "r")
			if f then
				run_status = f:read("*a")
				f:close()
			end
			local run_status = tonumber(run_status) or 0

			if CACHE_APP[name] and CACHE_APP[name].enabled == "yes" and run_status == 0 then
				res = 1
			end

			local tmp_name
			local path = string.format("/var/appmarket/%s/.pkg/container_name", name)
			local f = io.open(path, "r")
			if f then
				tmp_name = f:read("*l")
				f:close()
			end

			local up_status = 0
			if tmp_name then
				if container_status[tmp_name] == 1 then
					up_status = 1
				end
				if res == 1 and up_status == 1 then
					res = 1
				else
					res = 0
				end
			else
				if enabled == "yes" then
					res = 1
				end
			end

                        ctx:result_int(res) 
                end
        )
        ikdb:create_function('is_liked',1,
                function (ctx, name)
			local res = 0
			local is_liked=0
			local path = string.format("/var/appmarket/%s/.is_liked", name)
			local f = io.open(path, "r")
			if f then
				is_liked = f:read("*a")
				f:close()
			end
			local is_liked = tonumber(is_liked) or 0

			if CACHE_APP[name] and is_liked == 1 then
				res = 1
			end
                        ctx:result_int(res) 
                end
        )
        ikdb:create_function('has_newversion',2,
                function (ctx, name, new_version)
			local res = 0
			if CACHE_APP[name] and  CACHE_APP[name].current_version then
				local a,b,c = new_version:match("(%d+)%.(%d+)%.(%d+)")
				local tmp_new_version = tonumber(string.format("%d%04d%04d", a,b,c))
				
				local current_version = CACHE_APP[name].current_version
				local a,b,c = current_version:match("(%d+)%.(%d+)%.(%d+)")
				local tmp_current_version = tonumber(string.format("%d%04d%04d", a,b,c))

				if tmp_new_version > tmp_current_version then
					res = 1
				end
			end
                        ctx:result_int(res) 
                end
        )
        ikdb:create_function('current_version',1,
                function (ctx, name)
			local res = ""
			if CACHE_APP[name] and  CACHE_APP[name].current_version then
				res = CACHE_APP[name].current_version
			end
                        ctx:result_text(res) 
                end
        )

        ikdb:create_function('status',1,
                function (ctx, name)
			local res = 0
			local path = string.format("/var/appmarket/%s/status", name)
			local f = io.open(path, "r")
			if f then
				res = f:read("*a")
				f:close()
			end
		
                        ctx:result_int(res or 0) 
                end
        )
        ikdb:create_function('run_status',1,
                function (ctx, name)
			local res = 0
			local path = string.format("/var/appmarket/%s/log/run.status", name)
			local f = io.open(path, "r")
			if f then
				res = f:read("*a")
				f:close()
			end
		
                        ctx:result_int(res or 0) 
                end
        )

        ikdb:create_function('cpus_limit',1,
                function (ctx, name)
			local filename = string.format("/etc/mnt/ikuai/appmarket/%s/default_env", name)
			local file = io.open(filename)
			local res = "0"
			if file then
				for line in file:lines() do
					local key,value = string.match(line, "([^ ]+)=(.*)")
					if key and value and key == "CPUS_LIMIT" then
						res = value
					end
				end
				file:close()
			end

                        ctx:result_text(res or "0")
                end
        )
        ikdb:create_function('memory_limit',1,
                function (ctx, name)
			local filename = string.format("/etc/mnt/ikuai/appmarket/%s/default_env", name)
			local file = io.open(filename)
			local res = "0"
			if file then
				for line in file:lines() do
					local key,value = string.match(line, "([^ ]+)=(.*)")
					if key and value and key == "MEMORY_LIMIT" then
						res = value
					end
				end
				file:close()
			end

                        ctx:result_text(res or "0")
                end
        )
        ikdb:create_function('expose_port',1,
                function (ctx, name)
			local filename = string.format("/etc/mnt/ikuai/appmarket/%s/default_env", name)
			local file = io.open(filename)
			local res = 0
			if file then
				for line in file:lines() do
					local key,value = string.match(line, "([^ ]+)=(.*)")
					if key and value and key == "HOST_IP" then
						if value == "0.0.0.0" then
							res = 1
						end
					end
				end
				file:close()
			end

                        ctx:result_int(res or 0)
                end
        )
        ikdb:create_function('config_get',2,
                function (ctx, name, config)
			local res="{}"

			local env_table={}
			
			if config then
				local success, data = pcall(cjson.decode, config)
				if success then
					env_table = data
				end
			end

			local env_info = {}

			local filename = string.format("/etc/mnt/ikuai/appmarket/%s/environment", name)	
			local file = io.open(filename)
			if file then
				for line in file:lines() do
					local key,value = string.match(line, "([^ ]+)=(.*)")
					if key and value then
						env_info[key] = value
					end
				end
				file:close()
			end

			local filename = string.format("/etc/mnt/ikuai/appmarket/%s/default_env", name)	
			local file = io.open(filename)
			if file then
				for line in file:lines() do
					local key,value = string.match(line, "([^ ]+)=(.*)")
					if key and value then
						env_info[key] = value
					end
				end
				file:close()
			end

			for k,v in pairs(env_table) do
				local envkey = v.attrname
				local envdefault = env_info[envkey]
				if envdefault then
					local env_value
					if v.type == "integer" then
						env_value = tonumber(envdefault)
					else
						env_value = string.gsub(envdefault, "'", "")
					end
					env_table[k].default = env_value
				end
			end
			local success, data = pcall(cjson.encode, env_table)
			if success then
				res = data
			end

                        ctx:result_text(res or "{}") 
                end
        )
EOF
}


__queue_implant_code()
{
cat -<<EOF
        ikdb:create_function('status',1,
                function (ctx, name)
			local res = 0
			local path = string.format("/var/appmarket/%s/status", name)
			local f = io.open(path, "r")
			if f then
				res = f:read("*a")
				f:close()
			end
		
                        ctx:result_int(res or 0) 
                end
        )

        ikdb:create_function('message',1,
                function (ctx, name)
			local res = 0
			local path = string.format("/var/appmarket/%s/log/install.log", name)
			local f = io.open(path, "r")
			if f then
				res = f:read("*a")
				f:close()
			end
		
                        ctx:result_text(res or "") 
                end
        )
EOF
}


show() {
	local __filter=$(sql_auto_get_filter)
	local __order=$(sql_auto_get_order)
	local __limit=$(sql_auto_get_limit)
	local __where="$__filter $__order $__limit"
	Show __json_result__
}

__show_apps_data()
{
	local apps_status=0
	if [ ! -e "$IK_DIR_TMP/appmarket/.load_app" ]; then
		apps_status=0
		local workdisk=$(sqlite3 $IK_DB_DOCKER "select workdisk from global" 2>/dev/null)
		local __sql_implant_code__=$(__apps_implant_code)
		local sql_show="select *,config_get(name, config) config,location(name) location,ignore_update(name) ignore_update,is_liked(name) is_liked,is_installed(name) is_installed,is_enabled(name) is_enabled,has_newversion(name, new_version) has_newversion,status(name) status,run_status(name) run_status,current_version(name) current_version,cpus_limit(name) cpus_limit,memory_limit(name) memory_limit,expose_port(name) expose_port from applist $__where"
		local apps_data=$(sql_config_get_json $APPTMPDB "$sql_show")
		local apps_total=$(sqlite3 $APPTMPDB "select count(*) from applist $__filter")
	else
		apps_status=1
		apps_data="[]"
		apps_total=0
	fi
	json_append __json_result__ apps_data:json apps_total:int apps_status:int

	return 0
}

__show_apps_queue_total()
{
	local total=$(sqlite3 $IK_DB_APPMARKET "select count() from app_task_queue $__filter")
	json_append __json_result__ apps_queue_total:int
}

__show_apps_queue()
{
	local __sql_implant_code__=$(__queue_implant_code)
	local sql_show="select *,status(name) status,message(name) message from app_task_queue $__where"
	local apps_queue=$(sql_config_get_json $IK_DB_APPMARKET "$sql_show")
	json_append __json_result__ apps_queue:json

	return 0
}

__show_total()
{
	local total=$(sqlite3 $IK_DB_APPMARKET "select count() from applist $__filter")
	json_append __json_result__ total:int
}

#ignore_update=0|1
__show_data()
{
	local workdisk=$(sqlite3 $IK_DB_DOCKER "select workdisk from global" 2>/dev/null)
	local __sql_implant_code__=$(__implant_code)
	local sql_show="select enabled,ignore_update,name,appid,timestamp,display_name,location,ico,type,size,restart,current_version,maintainer,maintainer_url,distributor,distributor_url,origin,update_time,install_path,category,sub_category,is_installed(name) is_installed,is_liked(name) is_liked,new_version(name) new_version,has_newversion(name, current_version) has_newversion,newversion_update_time(name) newversion_update_time,current_download(name) download,current_stars(name) stars,is_enabled(enabled,name) is_enabled,status(name) status,run_status(name) run_status,desc_info(name,desc) desc,desc_url_info(name,desc_url) desc_url,readme_info(name,readme) readme,changelog_info(name,changelog) changelog from applist $__where"
	local data=$(sql_config_get_json $IK_DB_APPMARKET "$sql_show")
	json_append __json_result__ data:json

	return 0
}

#appid=
__show_login_uri()
{
	local login_uri=""
	local res=$(sql_config_get_list $IK_DB_APPMARKET "select type,name from applist where appid=$appid;")
	if [ "$res" ]; then
		local $res
		if [ -e "/var/appmarket/$name/.pkg" ]; then
			local default_iface=$(route -n |awk '{if(NR==3){print $NF;exit}}')
			local default_iface=${default_iface//_ad/}
			local ipaddr=$(cat /tmp/iktmp/monitor-link/$default_iface | awk '{print $3}')

			local res=$(cat /var/appmarket/$name/.pkg/app/.env)
			if [ "$res" ]; then
				local $res
			fi
			if [ "$type" = "0" ]; then
				if [ "$HOST_IP" = "0.0.0.0" ]; then
					ipaddr=$(interface_get_ipaddr lan1)
				else
					ipaddr=$HOST_IP
				fi

			else
				if [ "$HOST_IP" != "0.0.0.0" ]; then
					ipaddr=$(interface_get_ipaddr doc_app_default)
				fi
			fi
			if [ "$APP_PORT_WEB" ]; then
				local web_port="${APP_PORT_WEB}"

				if [ "$web_port" ]; then
					login_uri="http://${ipaddr}:${web_port}$APP_WEB_LOGIN_URI"
				else
					login_uri="http://$ipaddr"
				fi
			fi
		fi
	fi

        json_append __json_result__ login_uri:str
}

__get_app_diskused()
{
	if $LOCKUP_NB_DISKUSED; then
		touch ${IK_DIR_TMP}/appmarket/.load_diskused
		local filename="/tmp/iktmp/appmarket/diskused"
		> ${filename}.$$
		sql_config_get_list $IK_DB_APPMARKET "select * from applist where enabled='no';" |\
		while read config; do
			[ "$config" ] || continue
			local $config
			if [ -e "/var/appmarket/$name/.pkg" ]; then
				local diskused=$(du -s /var/appmarket/$name/ | awk '{print $1}')
				local disk_cache_used=$(du -s /var/appmarket/$name/.pkg/cache | awk '{print $1}')
				echo "name=$name disk_used=${diskused:-0} disk_cache_used=${disk_cache_used:-0}" >> ${filename}.$$
			fi
		done
		mv ${filename}.$$ ${filename}
		rm ${IK_DIR_TMP}/appmarket/.load_diskused
		$UNLOCK_DISKUSED
	fi
}

__diskused_implant_code()
{
cat -<<EOF
	local CACHE_USED = {}

        local f = io.open("/tmp/iktmp/appmarket/diskused")
        if f then
                for line in f:lines() do
                        local name,disk_used,disk_cache_used = line:match("^name=([^ ]+) +disk_used=([^ ]+) +disk_cache_used=([^ ]+)")
                        if name and disk_used and disk_cache_used then
                                CACHE_USED[name] = {disk_used=disk_used, disk_cache_used=disk_cache_used}
                        end
                end
                f:close()
        end

        ikdb:create_function('disk_used',1,
                function (ctx, name)
			local res = 0
			if CACHE_USED[name] then
				res = CACHE_USED[name].disk_used or 0
			end
                        ctx:result_int(res or 0)
                end
        )

        ikdb:create_function('disk_cache_used',1,
                function (ctx, name)
			local res = 0
			if CACHE_USED[name] then
				res = CACHE_USED[name].disk_cache_used or 0
			end
                        ctx:result_int(res or 0)
                end
        )
EOF
}


__show_diskused()
{
	local status=0
	if [ -e "${IK_DIR_TMP}/appmarket/.load_diskused" ]; then
		status=1
	fi

	__get_app_diskused >/dev/null 2>&1 &
	local __sql_implant_code__=$(__diskused_implant_code)

	local diskused=$(sql_config_get_json $IK_DB_APPMARKET "select disk_used(name) disk_used,disk_cache_used(name) disk_cache_used,* from applist where enabled='no';")

        json_append __json_result__ diskused:json status:int
}

#appid=
__show_config_tmp()
{
	local res=$(sql_config_get_list $IK_DB_APPMARKET "select name from applist where appid=$appid;")
	if [ "$res" ]; then
		local $res
		local tmpinfo=""
		if [ "$name" -a -e "/var/appmarket/$name/.pkg/app/environment" ]; then
			while read config; do
				local key=${config//=*/}
				if [[ "$key" =~ ^[a-zA-Z0-9_-]+$ ]]; then
					tmpinfo+="${tmpinfo:+,}\"$config\""
				fi
			done < /var/appmarket/$name/.pkg/app/environment
		fi
		if [ "$tmpinfo" ]; then
			local environment="[$tmpinfo]"
		else
			local environment="[]"
		fi

		local tmpinfo=""
		if [ "$name" -a -e "/var/appmarket/$name/.pkg/app/.env" ]; then
			while read config; do
				local key=${config//=*/}
				local exclude_key="CPUS_LIMIT,MEMORY_LIMIT,RESTART,HOST_IP,NAME_NONCE,IMAGE_VERSION"
				if [[ "$key" =~ ^[a-zA-Z0-9_-]+$ ]]; then
					local hit_key=0
					for key_one in ${exclude_key//,/ }; do
						if [ "$key_one" = "$key" ]; then
							hit_key=1	
						fi 
					done
					if [ "$hit_key" = "0" ]; then
						tmpinfo+="${tmpinfo:+,}\"$config\""
					fi
				fi
			done < /var/appmarket/$name/.pkg/app/.env
		fi
		if [ "$tmpinfo" ]; then
			local default_env="[$tmpinfo]"
		else
			local default_env="[]"
		fi

		local path=""
		local config=$(json_output environment:json default_env:json path:str)
	else
		local config="{}"
	fi
	
        json_append __json_result__ config:json
}


#appid=
__show_config_done()
{
	local res=$(sql_config_get_list $IK_DB_APPMARKET "select name from applist where appid=$appid;")
	if [ "$res" ]; then
		local $res
		local tmpinfo=""
		if [ "$name" -a -e "/etc/mnt/ikuai/appmarket/$name/environment" ]; then
			while read config; do
				local key=${config//=*/}
				if [[ "$key" =~ ^[a-zA-Z0-9_-]+$ ]]; then
					tmpinfo+="${tmpinfo:+,}\"$config\""
				fi
			done < /etc/mnt/ikuai/appmarket/$name/environment
		fi
		if [ "$tmpinfo" ]; then
			local environment="[$tmpinfo]"
		else
			local environment="[]"
		fi

		local tmpinfo=""
		if [ "$name" -a -e "/etc/mnt/ikuai/appmarket/$name/default_env" ]; then
			while read config; do
				local key=${config//=*/}
				local exclude_key="CPUS_LIMIT,MEMORY_LIMIT,RESTART,HOST_IP,NAME_NONCE,IMAGE_VERSION"
				if [[ "$key" =~ ^[a-zA-Z0-9_-]+$ ]]; then
					local hit_key=0
					for key_one in ${exclude_key//,/ }; do
						if [ "$key_one" = "$key" ]; then
							hit_key=1	
						fi 
					done
					if [ "$hit_key" = "0" ]; then
						tmpinfo+="${tmpinfo:+,}\"$config\""
					fi
				fi
			done < /etc/mnt/ikuai/appmarket/$name/default_env
		fi
		if [ "$tmpinfo" ]; then
			local default_env="[$tmpinfo]"
		else
			local default_env="[]"
		fi

		local path=""
		local config=$(json_output environment:json default_env:json path:str)
	else
		local config="{}"
	fi
	
        json_append __json_result__ config:json
}


__get_option_list()
{
	local name="$1" sqlcmd="$2"
	luajit<<EOF
	local cjson = require "cjson"
	local name = "$name"

	local env_table
	
	local filename = string.format("/var/appmarket/%s/.pkg/app/option.json", name)	
	local file = io.open(filename)
	if file then
		local res = file:read("*a")
		env_table = cjson.decode(res)
		file:close()
	end
	local env_info = {}

	local filename = string.format("/etc/mnt/ikuai/appmarket/%s/environment", name)	
	local file = io.open(filename)
	if file then
		for line in file:lines() do
			local key,value = string.match(line, "([^ ]+)=(.*)")
			if key and value then
				env_info[key] = value
			end
		end
		file:close()
	end

	local filename = string.format("/etc/mnt/ikuai/appmarket/%s/default_env", name)	
	local file = io.open(filename)
	if file then
		for line in file:lines() do
			local key,value = string.match(line, "([^ ]+)=(.*)")
			if key and value then
				env_info[key] = value
			end
		end
		file:close()
	end

	for k,v in pairs(env_table) do
		local envkey = v.attrname
		local envdefault = env_info[envkey]
		if envdefault then
			local env_value
			if v.type == "integer" then
				env_value = tonumber(envdefault)
			else
				env_value = string.gsub(envdefault, "'", "")
			end
			env_table[k].default = env_value
		end
	end
	print(cjson.encode(env_table))

EOF
}

#appid= 
__show_config()
{
	local memory_limit=0 cpus_limit=0 restart="always" host_ip="0.0.0.0" expose_port=0
	local res=$(sql_config_get_list $IK_DB_APPMARKET "select display_name,name,current_version,type from applist where appid=$appid;")
	if [ "$res" ]; then
		local $res
	fi
	if [ "$name" ]; then
		local config=$(__get_option_list "$name")
		if [ -e "/etc/mnt/ikuai/appmarket/$name/default_env" ]; then
			local $(cat /etc/mnt/ikuai/appmarket/$name/default_env)
		fi
		cpus_limit=${CPUS_LIMIT:-0}
		memory_limit=${MEMORY_LIMIT:-0}
		restart=${RESTART:-always}
		host_ip=${HOST_IP:-0.0.0.0}
		if [ "$host_ip" = "0.0.0.0" ]; then
			expose_port=1
		else
			expose_port=0
		fi
	else 
		local config="[]"
	fi

	sysstat_get_mem
	local total="${SYSSTAT_MEM[MemTotal]}"

	local max_cpus=$(cat /proc/cpuinfo |grep processor| wc -l)
	local max_memory=$((total/2048))

	json_append __json_result__ name:str display_name:str appid:int config:json cpus_limit:str expose_port:int memory_limit:str max_cpus:int max_memory:int restart:str host_ip:str current_version:str
}

#appid=
__show_default_config()
{
	local memory_limit=0 cpus_limit=0 restart="always" host_ip=""
	local $(sql_config_get_list $APPTMPDB "select display_name,name,new_version from applist where appid=$appid")

	local default_config=$(cat /etc/mnt/ikuai/appmarket/option.json)

	json_append __json_result__ display_name:str name:str version:str appid:int default_config:json cpus_limit:int memory_limit:int restart:str host_ip:str
}

__show_containterd_status()
{
	local upload_num=1
        local sql_show="select * from global"
        local data=$(sql_config_get_json $IK_DB_DOCKER "$sql_show")

        if killall -q -0 dockerd ;then
                local is_running=1
        else
                local is_running=0
        fi 
	if [ -d "/tmp/ikpkg/container-bin" ]; then
		local is_installed=1
	else
		local is_installed=0
	fi

	local upload_path=""
	if [ "$is_installed" ]; then
		local workdisk=$(sqlite3 $IK_DB_DOCKER "select workdisk from global")
		upload_path="/$workdisk/.pkg"
		if [ -d "$ROOT_PATH${workdisk}" ]; then
			mkdir -p $ROOT_PATH${workdisk}/.pkg
		fi
	fi


	local partname
	while read config; do
		local $config
		local mt_dir="/etc/disk/$mt_uuid"
		if [ "$mt_purpose" = "1" -a -n "$mt_name" -a -e "$mt_dir" ]; then
			local res=$(df | awk -v k="$mt_dir" '{if($6==k){print "total="$2,"used="$4;exit}}')
			if [ "$res" ]; then
				local $res
			fi
			local name=$mt_name
			partname+="${partname:+,}$(json_output name:str total:int used:int)"
		fi
	done < /tmp/iktmp/cache/disk_mount
	partname="[$partname]"

	sysstat_get_mem
	local total="${SYSSTAT_MEM[MemTotal]}"
	local memory_available="${SYSSTAT_MEM[MemAvailable]}"
	local memory_available="$((memory_available/1024))"

	local max_cpus=$(cat /proc/cpuinfo |grep processor| wc -l)
	local max_memory=$((total/2048))

	if [  "$ARCH" = "x86" -a -z "$ENTERPRISE" ]; then
		local count=$(sqlite3 $IK_DB_APPMARKET "select count() from applist where origin=3")
		if [ "$count" -gt "0" ]; then
			upload_num=0
		fi
	fi

        json_append __json_result__ data:json partname:json is_running:int is_installed:int upload_path:str upload_num:int max_cpus:int max_memory:int memory_available:int
}

#path=
__show_disks()
{
        local dirlist=$($IK_DIR_SCRIPT/utils/file_find.lua "$path" "$ORDER_BY" "$ORDER")
        json_append __json_result__ dirlist:json
}

#appid=
__show_install_log()
{
	local install_log=""
	local name=$(sqlite3 $IK_DB_APPMARKET "select name from applist where appid=$appid;")
	if [ -z "$name" ]; then
		local name=$(sql_config_get_list /etc/log/task_queue.db "select name from task_queue where task_key=$appid;")
	fi
	if [ "$name" -a -e "/var/appmarket/$name/log/install.log" ]; then
		local first=1
		while read line ;do
			line=$(echo "$line" | sed -e 's/\\/\\\\/g' -e 's/"/\\"/g' -e 's/\t/\\t/g')
			if [ $first -eq 1 ]; then
				install_log="\"$line\""
				first=0
			else
				install_log+="${install_log:+,}\"$line\""
			fi
		done < /var/appmarket/$name/log/install.log
	fi

	install_log="[$install_log]"
        json_append __json_result__ install_log:json
}

#appid=
__show_run_log()
{
	local run_log=""
	local name=$(sqlite3 $IK_DB_APPMARKET "select name from applist where appid=$appid;")
	local logfile="/var/appmarket/$name/log/run.log"
	if [ "$name" -a -e "$logfile" ]; then
		local first=1
		while read line ;do
			line=$(echo "$line" | sed -e 's/\\/\\\\/g' -e 's/"/\\"/g' -e 's/\t/\\t/g' -e '/Found orphan containers/d')
			if [ $first -eq 1 ]; then
				run_log="\"$line\""
				first=0
			else
				run_log+="${run_log:+,}\"$line\""
			fi
		done < <(tail -n "$APPMARKET_SHOW_LOG_LINES" "$logfile" 2>/dev/null)
	fi

	run_log="[$run_log]"

        json_append __json_result__ run_log:json
}

__show_native_log()
{
	local run_log=""
	local name=$(sqlite3 $IK_DB_APPMARKET "select name from applist where appid=$appid;")
	local logfile="/var/appmarket/$name/.pkg/log/run.log"
	if [ "$name" -a -e "$logfile" ]; then
		local first=1
		while read line ;do
			line=$(echo "$line" | sed -e 's/\\/\\\\/g' -e 's/"/\\"/g' -e 's/\t/\\t/g' -e '/Found orphan containers/d')
			if [ $first -eq 1 ]; then
				run_log="\"$line\""
				first=0
			else
				run_log+="${run_log:+,}\"$line\""
			fi
		done < <(tail -n "$APPMARKET_SHOW_LOG_LINES" "$logfile" 2>/dev/null)
	fi

	local native_log="[$run_log]"

        json_append __json_result__ native_log:json
}

#appid=
__show_container_log()
{
	local container_log=""
	local res=$(sql_config_get_list $IK_DB_APPMARKET "select name from applist where appid=$appid;")
	if [ "$res" ]; then
		local $res
		if [ -e "/var/appmarket/$name/.pkg/app/docker-compose.yaml" ]; then
			cd /var/appmarket/$name/.pkg/app
			container_log="$(docker-compose logs -n 100 2>/dev/null)"
			container_log=${container_log//$LINE_N/\\n}	
		fi
	fi

        json_append __json_result__ container_log:str
}

__check_manifest_params()
{
	# 规则1: name 不能为空，name只允许字母数字下划线连字符，长度不能超过32个字符
	if [ -z "$name" ]; then
		echo "name不能为空"
		return 1
	elif ! [[ "$name" =~ ^[a-zA-Z0-9_-]+$ ]]; then
		echo "name只允许字母数字下划线连字符"
		return 1
	elif [ ${#name} -gt 64 ]; then
		echo "name长度不能超过32个字符 (当前: ${#name})"
		return 1
	fi

	# 规则2: version 不能为空， 格式xx.xx.xx， 例如 1.0.0
	if [ -z "$new_version" ]; then
		echo "version不能为空"
		return 1
	elif ! [[ "$new_version" =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
		echo "version格式错误，必须为xx.xx.xx格式 (例如: 1.0.0)"
		return 1
	fi

	# 规则3: display_name 不能为空, 不允许特殊字符，可以有空格，长度不能超过32个字符
	if [ -z "$display_name" ]; then
		echo "display_name不能为空"
		return 1
	# 允许中文、英文、数字、空格、下划线、连字符
	elif echo "$display_name" | grep -qE '[<>"'"'"'`;${}\\|]'; then
		echo "display_name包含不允许的特殊字符"
		return 1
	elif [ ${#display_name} -gt 64 ]; then
		echo "display_name长度不能超过32个字符 (当前: ${#display_name})"
		return 1
	fi

	# 规则4: description 不能为空，不允许有特殊字符，可以有空格，长度不能超过256个字符
	if [ -z "$description" ]; then
		echo "description不能为空"
		return 1
	# 允许中文、英文、数字、空格、常见中文标点和部分英文标点
	elif echo "$description" | grep -qE '[<>"'"'"';`${}\\]'; then
		echo "description包含不允许的特殊字符"
		return 1
	elif [ ${#description} -gt 6000 ]; then
		echo "description长度不能超过6000个字符 (当前: ${#description})"
		return 1
	fi

	# 规则5: type 不能为空， 只能为0 或者为1
	if [ -z "$type" ]; then
		echo "type不能为空"
		return 1
#	elif [ "$type" != "0" ] && [ "$type" != "1" ]; then
	elif [ "$type" != "1" ]; then
		echo "type只能为1,目前支持docker类型 (当前: $type)"
		return 1
	fi

	# 规则6: maintainer 不能为空，不允许特殊字符，可以有空格，长度不能超过32个字符
	if [ -z "$maintainer" ]; then
		echo "maintainer不能为空"
		return 1
	# 允许中文、英文、数字、空格、下划线、连字符
	elif echo "$maintainer" | grep -qE '[<>"'"'"'`;${}\\|]'; then
		echo "maintainer包含不允许的特殊字符"
		return 1
	elif [ ${#maintainer} -gt 64 ]; then
		echo "maintainer长度不能超过32个字符 (当前: ${#maintainer})"
		return 1
	fi

	# 规则8: distributor 不能为空，不允许特殊字符，可以有空格，长度不能超过32个字符
	if [ -z "$distributor" ]; then
		echo "distributor不能为空"
		return 1
	# 允许中文、英文、数字、空格、下划线、连字符
	elif echo "$distributor" | grep -qE '[<>"'"'"'`;${}\\|]'; then
		echo "distributor包含不允许的特殊字符"
		return 1
	elif [ ${#distributor} -gt 64 ]; then
		echo "distributor长度不能超过32个字符 (当前: ${#distributor})"
		return 1
	fi

	# 可选字段验证 (maintainer_url, distributor_url不在必需规则中，但如果存在应该验证URL格式)
	if [ -n "$maintainer_url" ]; then
		if ! [[ "$maintainer_url" =~ ^https?://[a-zA-Z0-9\.\-/_:]+.*$ ]]; then
			echo "maintainer_url格式错误，必须是有效的HTTP/HTTPS URL"
			return 1
		fi
	fi

	if [ -n "$distributor_url" ]; then
		if ! [[ "$distributor_url" =~ ^https?://[a-zA-Z0-9\.\-/_:]+.*$ ]]; then
			echo "distributor_url格式错误，必须是有效的HTTP/HTTPS URL"
			return 1
		fi
	fi

	if [ -n "$os_min_version" ]; then
		if ! [[ "$os_min_version" =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
			echo "os_min_version格式错误，必须为xx.xx.xx格式"
			return 1
		fi
	fi
	return 0
}

__parser_file()
{
	rm -rf $pkg_path/$IKREST_SESSION/* >/dev/null 2>&1
	mkdir -p $pkg_path/$IKREST_SESSION
	if $LOCKUP_NB_INSTALL; then
		touch ${pkg_path}/$IKREST_SESSION/.install
		if [ "$filename" -a -e "$pkg_path/$filename" ]; then

			if ! tar -zxf $pkg_path/$filename -C $pkg_path/$IKREST_SESSION 2>/dev/null; then
				rm $pkg_path/$filename
				touch ${pkg_path}/${IKREST_SESSION}/.error
			else
				touch ${pkg_path}/${IKREST_SESSION}/.success
			fi
		fi
		rm ${pkg_path}/$IKREST_SESSION/.install
		$UNLOCK_INSTALL
	fi
	return 0
}

#filename=
parser_file()
{
	local workdisk=$(sqlite3 $IK_DB_DOCKER "select workdisk from global")

	if [ ! -d "${ROOT_PATH}$workdisk" ]; then
		outputErrorLog "errcode_dir_not_found"
		return 1
	fi

	local pkg_path="${ROOT_PATH}${workdisk}/.pkg"

	local fileinfo="{}"
	if [ -z "$IKREST_SESSION" ]; then
		echo "set IKREST_SESSION"
		return 1
	fi
	__parser_file >/dev/null 2>&1 &
}

#filename=
__show_fileinfo()
{
	local status=0
	local message=""

	local workdisk=$(sqlite3 $IK_DB_DOCKER "select workdisk from global")


	if [ ! -d "${ROOT_PATH}$workdisk" ]; then
		outputErrorLog "errcode_dir_not_found"
		return 1
	fi

	local pkg_path="${ROOT_PATH}${workdisk}/.pkg"

	local fileinfo="{}"
	if [ -z "$IKREST_SESSION" ]; then
		echo "set IKREST_SESSION"
		return 1
	fi
	local appid=0
#	__parser_file >/dev/null 2>&1 &
#		if [ "$filename" -a -e "$pkg_path/$filename" ]; then
#			mkdir -p $pkg_path/$IKREST_SESSION
#			if [ "$IKREST_SESSION" ]; then
#				rm -rf $pkg_path/$IKREST_SESSION/*
#			fi
#
#			if ! tar -zxf $pkg_path/$filename -C $pkg_path/$IKREST_SESSION 2>/dev/null; then
#				rm $pkg_path/$filename
#				local status=1	
#				local message="$filename 解压失败"
#				local type=1
#				$UNLOCK_INSTALL
#				json_append __json_result__ fileinfo:json name:str current_version:str type:int status:int message:str
#			fi
#			rm  $pkg_path/$filename
#		fi
	
	if [ ! -e "${pkg_path}/$IKREST_SESSION/.install" ]; then
		if [ -e "${pkg_path}/$IKREST_SESSION/.success" ]; then
			local name=$(ls $pkg_path/$IKREST_SESSION/)
			if [ "$name" ]; then
				local filepath="$pkg_path/$IKREST_SESSION/$name/manifest.json"
				if [ -e "$filepath" ]; then
					json_decode_file manifest $filepath

					local name="${manifest_name}" display_name="${manifest_display_name// /%20}" type="${manifest_type}"
					local new_version="${manifest_version}" maintainer="${manifest_maintainer// /%20}" maintainer_url="${manifest_maintainer_url}"
					local distributor="${manifest_distributor// /%20}" distributor_url="${manifest_distributor_url}"
					local description="${manifest_description}"
					local os_min_version="${manifest_requirements_os_min_version}"

					if ! errmsg=$(__check_manifest_params); then
						status=2	
						message="manifest.json: $errmsg"
					fi
#					else
#						local min_version="$manifest_requirements_os_min_version"
#						if [ "$manifest_requirements_os_min_version" = "null" ]; then
#							min_version="4.0.0"
#						fi
#						if [ "$(Version $VERSION)" -lt "$(Version $min_version)" ]; then
#							status=2
#							message="manifest.json: Minimum Version Requirements $min_version"
#						fi
#					fi
					if [ "$type" != "1" ]; then
						status=2
						message="安装包错误: manifest.json type仅支持docker应用"
					fi
				else
					status=2
					message="安装包错误: 缺少manifest.json"
				fi
			else
				status=2
				message="安装包错误"
			fi
			
			if [ "$status" = "0" ]; then
				local name="${manifest_name}"
				local new_version="${manifest_version}" 
				local new_type="${manifest_type}"
				local res=$(sql_config_get_list $IK_DB_APPMARKET "select appid,display_name,name,current_version,type from applist where name='$name'")
				if [ "$res" ]; then
					local $res
#					if [ "$new_type" != "$type" ]; then
#						status=3
#						message="插件类型不一致"
#					fi
				fi
				local fileinfo=$(cat $filepath)
				local readme=$(cat $pkg_path/$IKREST_SESSION/$name/readme 2>/dev/null)
				local readme=$(echo -n "$readme" | base64 | tr -d '\n')
				local config=$(cat $pkg_path/$IKREST_SESSION/$name/app/option.json 2>/dev/null)
				if ! echo "$config" |jq . >/dev/null 2>&1; then
					config="{}"
				fi
				if [ -e "$pkg_path/$IKREST_SESSION/$name/ui/ico/app.png" ]; then
					cp $pkg_path/$IKREST_SESSION/$name/ui/ico/app.png /usr/ikuai/www/static/images/$name.png
					ico="/static/images/$name.png"
				fi
			fi
		elif [ -e "${pkg_path}/$IKREST_SESSION/.error" ]; then
			status=2
			message="安装包解压失败"
		else
			status=1
			message="应用安装中"
		fi
	else
		status=1
		message="应用安装中"
	fi
	if [ -z "$config" ]; then
		config="{}"
	fi

	sysstat_get_mem
	local total="${SYSSTAT_MEM[MemTotal]}"
	local memory_available="${SYSSTAT_MEM[MemAvailable]}"
	local memory_available="$((memory_available/1024))"

	local max_cpus=$(cat /proc/cpuinfo |grep processor| wc -l)
	local max_memory=$((total/2048))

        json_append __json_result__ max_cpus:int max_memory:int readme:str config:json fileinfo:json name:str display_name:str appid:int current_version:str status:int message:str ico:str
}

__show_limit()
{
	sysstat_get_mem
	local total="${SYSSTAT_MEM[MemTotal]}"
	local memory_available="${SYSSTAT_MEM[MemAvailable]}"

	local max_cpus=$(cat /proc/cpuinfo |grep processor| wc -l)
	local max_memory=$((total/2048))
	local memory_available="$((memory_available/1024))"


	json_append __json_result__ max_cpus:int max_memory:int memory_available:int
}

__show_sync_apps()
{
	__apps_list_get >/dev/null 2>&1 &
	local status=0
	json_append __json_result__ status:int
}

__show_support_loacl_install()
{
	#arm/support docker true
	support_local_install=1
	if [ "$ARCH" == "arm" -a "$SUPPORT_DOCKER" != "true" ];then
		support_local_install=0
	fi
	json_append __json_result__ support_local_install:int
}
