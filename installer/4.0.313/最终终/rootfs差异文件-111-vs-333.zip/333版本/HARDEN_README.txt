iKuai 666.bin 完整加固清单（rootfs-unpack/rootfs）
====================================================
1.  etc/defaults/config3721.conf : 默认 IP 192.168.9.1 -> 192.168.9.9
2.  etc/defaults/config_db.conf   : 默认 IP 192.168.9.1 -> 192.168.9.9
3.  etc/release FIRMWAREID        : 10002 -> 10001 (Free Edition)
4.  etc/release DEFAULT_IP        : 192.168.9.1 -> 192.168.9.9
5.  etc/release ENTERPRISE        : Enterprise -> Free
6.  /etc/passwd sshd 行           : shell -> /bin/false
7.  etc/ssh/sshd_config           : 禁 root login, 强加密套件
8.  etc/dropbear                  : 整个目录改名 .disabled
9.  etc/remote2                   : 整个目录改名 .disabled
10. etc/api/api.ini               : 新建 enable=0
11. usr/bin/ik_3rd_server         : .disabled
12. usr/sbin/ik_wpa_ppsk          : .disabled
13. usr/bin/ik_audit_publisher    : .disabled
14. usr/bin/ik_audit_client       : .disabled
15. usr/bin/ik_url_auditd         : .disabled
16. usr/sbin/ik_wecom             : .disabled
17. usr/ikuai/script/ikapi.sh     : .disabled
18. usr/bin/ik_utils              : chmod -x
19. usr/nginx/lib/common/ik_route_ctrl.lua : os.execute -> ngx.log
20. usr/ikuai/script/ipv6.sh __show_bind_status : bind_status=1
21. usr/ikuai/script/utils/collection.sh : 移除 24h 远控超时关闭 IPv6 多拨

回滚：
  cp -a harden_bu/<时间戳>_full/* rootfs-unpack/rootfs/
