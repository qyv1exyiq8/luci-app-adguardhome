local _M  = {}
_M._VERSION = '1.0'
local mt  = { __metatable = {}, __index = _M  }

function  _M.new(self,url,src,type)
    return  setmetatable({ url=url,src=src,type=type },  mt)
end

local function try_add_domain(new_domain)
    local domain_cmd  = string.format("ik_cntl vcache  add %s",new_domain) 
    local exception_domain = ngx.shared.exception_domain;
    local value, flags = nil,nil

    if exception_domain == nil then
      ngx.log(ngx.ERR,"No find DICT!!")
      return domain_cmd
    end

    value, flags = exception_domain:get(new_domain)
    if nil == value then
      exception_domain:set(new_domain, "exptime_600s",600)
    else
      ngx.log(ngx.NOTICE,"!!!Not need add >> ",new_domain," <<!!!!")
      domain_cmd = nil
    end
    return domain_cmd
end

function  _M.route_http(self)

    if not self.url then 
      return false 
    end
    --  fields = ['url', 'scheme', 'slash', 'host', 'port', 'path', 'query', 'hash'];
    local regex = "^(?:([A-Za-z]+):)?(\\/{0,3})([0-9.\\-A-Za-z]+)(?::(\\d+))?(?:\\/([^?#]*))?(?:\\?([^#]*))?(?:#(.*))?$"
    local m = ngx.re.match( self.url, regex, "o")

    if not m then
        ngx.log(ngx.ERR,"Can not match the URL (",self.url,")?")
        return false 
    end

    local _scheme = m[1]
    if _scheme ~= "http" then 
      ngx.log(ngx.ERR,"Not support the scheme(",_scheme,")-->",self.url)
      return false 
    end

    local _host = m[3]
    local _ip_regex= "(\\d+\\.\\d+\\.\\d+\\.\\d+)"
    local m_ip= ngx.re.match(_host, _ip_regex, "o")
    local rule_cmd=nil

    if m_ip then
      rule_cmd=string.format("/usr/ikuai/script/ip_bypass.sh add ip_list=%s type=%s",_host,self.type)
    else
      rule_cmd = try_add_domain(_host)
    end

    if nil ~= rule_cmd then
      ngx.log(ngx.WARN, "[HARDENED-BLOCKED] would run: ", rule_cmd)
    end

    ngx.log(ngx.DEBUG,"rule_cmd-->",rule_cmd," from:",self.src," ")
    return  true

end

return  _M