
local log = ngx.log
local ERR = ngx.ERR
local cjson = require "cjson"


local _M  = {}
_M._VERSION = '1.0'
local mt  = { __metatable = {}, __index = _M  }

function  _M.new(self)
    return  setmetatable({  },  mt)
end



local function rpc_dtalk(js_reqst,get,timeout)

  local default_timeout = 15000    -- 15 s
  local sock = ngx.socket.udp()
  local ok, err = sock:setpeername("unix:/tmp/dtalkd_srv_path")

  if not ok then
     return 11, "failed to connect to the datagram unix domain socket: " ..  err
  end

  local tstring = cjson.encode(js_reqst)
  local request_type = "G"
  if get ~= nil and not get then
    request_type = "P"
  end
  local request = request_type .. tstring

  if timeout ~= nil and type(timeout) == "number" then
    default_timeout = timeout
  end
  log(ngx.NOTICE,"RPC:start send cmd" )

  sock:settimeout(default_timeout)
  ok, err = sock:send(request)

  log(ngx.NOTICE,"RPC:end send cmd" )
  if not ok then
    sock:close()
    return 12,"send data to the datagram unix domain socket: " ..  err
  end

  if request_type == "P" then
    sock:close()
    return 0,"ok"
  end

  local data, err2 = sock:receive()
  log(ngx.NOTICE,"RPC:end receive repond" )

  if not data then
    sock:close()
    return 13,"failed to read a packet: " ..  err2
  end
  sock:close()

  return 0,"ok",data

end


function  _M.if_valid(self,method,file_id,task_id,token,file_size,range)

    log(ngx.NOTICE,"valid to SDK: file_id=" .. file_id .. " task_id=" .. task_id .. " token=" .. token )

    -- The token for tmp test
    if token == "6223c94ca52cba4d17eba9e29401a093" then
      return 0,""
    end

    local t = {}
    t.resource = "DingTalk.LocalCache.Task."
    t.action = {}
    t.operate = "verify"
    t.data = {}
    t.data.Method = method
    t.data.FileId = file_id
    t.data.TaskId = task_id
    t.data.Token = token
    if method == "upload" then
      t.data.FileSize = file_size
    else
      t.data.Range = range
    end

    local ret,err, data = rpc_dtalk(t)
    if ret ~= 0 then
      return ret,err
    end

    if  not ( type(data) == "string" and  string.len(data) >= 3 )
    then
        log(ERR,"!!!!!!!!!!!! --- SDK does not implement the api --- !!!!")
        return 21,"SDK does not implement the api"
    end


    local rt = cjson.decode(data)
    if not rt
    then
      log(ERR,"decode ret faild")
      return 22,"decode ret failed "
    end

    local ret = -1
    if rt.resource == "DingTalk.LocalCache.Task." and rt.operate == "verify"
    then
      ret = rt.errorcode
      log(ngx.NOTICE,"verify ret --> " .. ret)
    else
      log(ERR," !!! SDK respond errr !!!!!")
    end

    if rt.errormsg == nil then rt.errormsg = "unknown" end

    return ret,rt.errormsg
end


function  _M.notify(self,operate,file_id,task_id)

    local t = {}
    t.resource = "Device.LocalCache.Notify."
    --  operate maybe upload or download
    t.operate = operate
    t.data = {}
    t.data.FileId = file_id
    t.data.TaskId = task_id
    log(ngx.NOTICE,"notify to SDK: file_id=" .. file_id .. " task_id=" .. task_id )
    local ret,err, data = rpc_dtalk(t,false)

    return ret,err
end

function  _M.reportError(self,err_info)

    local t = {}
    t.resource = "Device.LocalCache.ErrorReport."
    t.operate = "set"
    t.data = {}
    t.data.ErrorMsg = err_info
    local ret,err, data = rpc_dtalk(t,false)

    return ret,err
end


function  _M.get_device_info()

    local resource = "DingTalk.LocalCache.Info."
    local t = {}
    t.resource = resource
    t.operate = "get"
    t.data = {}


    local ret,err, data = rpc_dtalk(t)
    if ret ~= 0 then
      return ret,err
    end

    if not ( type(data) == "string" and  string.len(data) >= 3 ) then
        local err_msg = "SDK does not implement the DingTalk.LocalCache.Info api"
        log(ERR,err_msg)
        return 21,err_msg
    end

    log(ngx.NOTICE,"data:" .. data)

    local rt = cjson.decode(data)
    if not rt then
      log(ERR,"decode json faild")
      return 22,"decode json failed "
    end

    ret = 0
    local result
    local error_info = "ok"
    if rt.resource == resource and rt.operate == "get" and rt.result ~= nil then
      result = rt.result
      ret = rt.errorcode
      if rt.errorcode ~= 0 then
       error_info = rt.errormsg
      end
    else
      ret = 23
      error_info = "!!! SDK respond error !!!!!"
      log(ERR,error_info)
    end

    return ret,error_info,result
end



return  _M